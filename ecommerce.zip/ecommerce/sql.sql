-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2025 at 08:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(12, 1, 3, 1, '2025-01-25 18:25:58', '2025-01-25 18:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `payment_method` varchar(255) NOT NULL,
  `payment_details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_cost`, `address`, `phone`, `order_date`, `payment_method`, `payment_details`) VALUES
(1, 1, 14500.00, 'Vijayawada', '8074223801', '2025-01-25 16:09:37', '', NULL),
(2, 3, 14649.00, 'Vijayawada', '9988776655', '2025-01-25 17:10:00', '', NULL),
(3, 4, 149.00, 'Vijayawada', '9988776655', '2025-01-25 17:30:34', '', NULL),
(4, 1, 1600.00, 'Vijayawada', '9988776655', '2025-01-25 21:54:19', '', NULL),
(6, 1, 800.00, 'Vijayawada', '9988776655', '2025-01-25 22:12:48', '', NULL),
(7, 1, 800.00, 'jaggayyapeta', '9988776644', '2025-01-25 23:42:48', '', NULL),
(8, 1, 78908.00, 'vijayawada', '9988776644', '2025-01-25 23:43:29', '', NULL),
(9, 1, 149.00, 'vijayawada', '9988776644', '2025-01-25 23:55:10', '', NULL),
(10, 1, 149.00, 'vijayawada', '9988776655', '2025-01-25 23:55:21', '', NULL),
(11, 1, 149.00, '', '', '2025-01-26 00:18:43', 'cod', 'Cash on Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(3, 2, 1, 1),
(4, 3, 3, 1),
(5, 4, 6, 2),
(7, 6, 6, 1),
(8, 7, 6, 1),
(9, 8, 9, 1),
(10, 9, 3, 1),
(11, 10, 3, 1),
(12, 11, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock` int(11) NOT NULL DEFAULT 0,
  `category` varchar(100) NOT NULL,
  `sku` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`, `created_at`, `stock`, `category`, `sku`) VALUES
(1, 'samsung s23', 14500.00, 'samsung s23 mobile', '../product_images/samsungs23.jpg', '2025-01-25 09:20:54', 5, 'Phones', 'PHO-6794CB247412'),
(3, 'LED Bulb 10W', 149.00, 'Energy-efficient 10W LED bulb, suitable for home and office use.', 'ledbulb.jpg', '2025-01-25 11:35:27', 198, 'Furniture', 'FUR-6794CC7F8323'),
(4, 'Electric Kettle 1.5L', 1199.00, '1.5L electric kettle with auto shut-off feature.', 'kettle.jpg', '2025-01-25 12:28:35', 80, 'Furniture', 'FUR-6794D8F31391'),
(6, 'Web Development', 800.00, 'Web Development Book', 'webdev.jpg', '2025-01-25 12:34:18', 6, 'Books', 'BOO-6794DA4A305'),
(7, 'Python', 399.00, 'Introduction to the python', 'python.png', '2025-01-25 16:52:43', 37, 'Books', 'BOO-679516DB9800'),
(8, 'Bedroom Furniture', 25776.00, 'Melrose Discount Furniture is one of the top discount stores in Los Angeles. We pride ourselves on high-quality selections sold at affordable prices delivered and assembled at your house completely free of charge! We offer various choices in a wide variety of shapes, sizes, and styles so you can find the perfect piece of interior decor to spice up your living room, bedroom, or office! Check out the wide selection from one of the cheap furniture stores in Los Angeles!\r\nInterior design is one of the key factors in creating the best environment in your house to make you feel comfortable and relaxed and it all starts with the type of interior decor items you pick. We work with various high-quality brands to ensure we deliver the best quality furniture to you which will bring value to you and your family.', 'bedroom.jpg', '2025-01-25 17:13:52', 10, 'Furniture', 'FUR-67951BD04226'),
(9, 'MacBook Air M1', 78908.00, 'MacBook Air M1 (33.74 cm / 13&quot;, 256 GB): The effective starting price on cards is ₹78,908 after cashback and discounts.', 'mackbookair13.jpg', '2025-01-25 17:22:54', 2, 'Laptops', 'LAP-67951DEE2530'),
(10, 'HP Pavilion 15', 75000.00, 'HP Pavilion 15-eg2025nr: This laptop features a 12th Generation Intel Core i7-1255U processor, 16 GB of RAM, and a 512 GB SSD. It has a 15.6-inch Full HD display and runs on Windows 11 Pro. It also includes a fingerprint reader, Wi-Fi, Bluetooth, and an HD webcam. This model is known for its sleek design and outstanding performance.', 'hppavilion15.jpeg', '2025-01-25 18:51:04', 21, 'Laptops', 'LAP-679532987409'),
(11, 'Apple iPhone 15 Pro Max', 121768.00, 'Supports MCPTT Quality of Service (FirstNet Rapid Response and FirstNet Push-to-Talk)\r\nForged in titanium – iPhone 15 Pro Max has a strong and light aerospace-grade titanium design with a textured matte-glass back. It also features a Ceramic Shield front that’s tougher than any smartphone glass. And it’s splash, water and dust resistant.¹', 'iphone15pro.png', '2025-01-25 18:54:41', 4, 'Phones', 'PHO-679533717680'),
(12, 'ASUS Vivobook Go 15.6&quot; OLED Laptop', 47329.57, 'ASUS Vivobook Go 15.6&quot; OLED Laptop, AMD Ryzen 5 7520U, 16GB, 512GB, Windows 11 Home, Cool Silver, E1504FA-NS54', 'asusvivobook.jpg', '2025-01-25 18:57:35', 28, 'Laptops', 'LAP-6795341F3076');

-- --------------------------------------------------------

--
-- Table structure for table `stock_movements`
--

CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `change_amount` int(11) DEFAULT NULL,
  `change_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `action` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('user','admin') DEFAULT 'user',
  `full_name` varchar(100) NOT NULL,
  `pincode` varchar(6) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `address`, `created_at`, `role`, `full_name`, `pincode`, `location`, `profile_picture`) VALUES
(1, '', 'mohanbalu292@gmail.com', '$2y$10$xjW64A.Xe6AgtfE1w191eexqCqXJaQOKIbhAeboGFQECxsIYXNhRu', '8074223801', 'vijayawada', '2025-01-25 09:35:02', 'user', 'Mohan balu', '521175', 'jaggayyapeta', '../uploads/profilemine.png'),
(2, '', 'saradhi@gmail.com', '$2y$10$hz/gIPaLYnbbOEAE8cw0A.8yLWl71EV4M1bE4ZMFYPF2JfSYR/EIy', '9440738630', 'jaggayyapeta , andhra pradesh', '2025-01-25 10:19:08', 'user', 'saradhi', '521175', 'Jaggayyapeta', '../uploads/Offer-Letter-prodigy.png'),
(3, '', 'arjun@gmail.com', '$2y$10$fxhUevsHFCLGUXvmeDzZaO1sSyE.yGnqqNqWN6MivOOHcicDV2B6G', '9988776655', 'Hyderbad , Telangana', '2025-01-25 11:38:43', 'user', 'allu arjun', '527175', 'Hyderbad', '../uploads/alluarjun.jpg'),
(4, '', 'admin@gmail.com', '$2y$10$WP0fWhua7XBtP5WDTq/JG.EgeXz/pqoVccrjVQCq7T1Mm05bXDiQC', '9988776644', 'SRM UNVI', '2025-01-25 11:43:27', 'admin', 'admin', '521175', 'Hyderbad', '../uploads/admin.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stock_movements`
--
ALTER TABLE `stock_movements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
