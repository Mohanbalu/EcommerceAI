<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Enhance session security
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6;
            color: #1f2937;
            line-height: 1.6;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 2rem auto;
            background-color: #ffffff;
            padding: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
        }

        h2 {
            text-align: center;
            color: #111827;
            font-size: 1.875rem;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }

        .welcome-header {
            text-align: center;
            color: #4b5563;
            font-size: 1.25rem;
            margin-bottom: 2rem;
        }

        nav {
            background-color: #ffffff;
            padding: 1rem;
            margin-bottom: 2rem;
            border-radius: 8px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 1rem;
        }

        nav a {
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            color: #4b5563;
            font-weight: 500;
            border-radius: 6px;
            transition: all 0.2s ease;
        }

        nav a:hover {
            background-color: #f3f4f6;
            color: #1f2937;
        }

        .logout {
            background-color: #ef4444;
            color: white !important;
        }

        .logout:hover {
            background-color: #dc2626;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }

        .stat-card {
            background-color: #ffffff;
            padding: 1.5rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            transition: transform 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card h3 {
            color: #6b7280;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }

        .stat-card p {
            color: #111827;
            font-size: 1.875rem;
            font-weight: 600;
        }

        .sales-section {
            margin-top: 3rem;
        }

        .sales-section h3 {
            color: #374151;
            font-size: 1.25rem;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 1rem;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        th {
            background-color: #f9fafb;
            color: #4b5563;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }

        tr:hover td {
            background-color: #f9fafb;
        }

        td {
            background-color: #ffffff;
            color: #4b5563;
        }

        .currency {
            font-family: monospace;
            color: #047857;
            font-weight: 500;
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 1rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            nav {
                flex-direction: column;
                gap: 1rem;
            }

            .nav-links {
                flex-direction: column;
                width: 100%;
            }

            nav a {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="welcome-header">
            Welcome, <?php echo isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name'], ENT_QUOTES, 'UTF-8') : 'Admin'; ?>!
        </h2>
        
        <nav>
            <div class="nav-links">
                <a href="dashboard.php">Admin Panel</a>
                <a href="data_monitoring.php">Data Monitoring</a>
                <a href="products.php">Products</a>
            </div>
            <a href="logout.php" class="logout">Logout</a>
        </nav>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Sales</h3>
                <p class="currency"><?php
                    $stmt = $conn->prepare("SELECT SUM(total_cost) FROM orders");
                    $stmt->execute();
                    echo '₹' . number_format($stmt->fetchColumn(), 2);
                ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Orders</h3>
                <p><?php 
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM orders");
                    $stmt->execute();
                    echo number_format($stmt->fetchColumn()); 
                ?></p>
            </div>
        </div>

        <div class="sales-section">
            <h3>Sales by Product</h3>
            <table>
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Total Sold</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $conn->prepare("
                        SELECT p.name, SUM(od.quantity) AS total_sold, SUM(od.quantity * p.price) AS total_revenue
                        FROM order_details od
                        JOIN products p ON od.product_id = p.id
                        GROUP BY p.id
                    ");
                    $stmt->execute();
                    $sales_data = $stmt->fetchAll();

                    foreach ($sales_data as $row) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8') . "</td>
                                <td>" . number_format($row['total_sold']) . "</td>
                                <td class='currency'>₹" . number_format($row['total_revenue'], 2) . "</td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>