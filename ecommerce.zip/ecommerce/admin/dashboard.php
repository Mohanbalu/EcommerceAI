<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Enhance session security
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

// Fetch statistics
$stmt = $conn->prepare("SELECT COUNT(*) FROM products");
$stmt->execute();
$totalProducts = $stmt->fetchColumn();

$stmt = $conn->prepare("SELECT COUNT(*) FROM orders");
$stmt->execute();
$totalOrders = $stmt->fetchColumn();

// Get recent orders
$stmt = $conn->prepare("
    SELECT o.id, o.total_cost, o.order_date, u.full_name 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.order_date DESC 
    LIMIT 5
");
$stmt->execute();
$recentOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get top products
$stmt = $conn->prepare("
    SELECT p.name, COUNT(oi.product_id) as order_count 
    FROM products p 
    LEFT JOIN order_details oi ON p.id = oi.product_id 
    GROUP BY p.id 
    ORDER BY order_count DESC 
    LIMIT 5
");
$stmt->execute();
$topProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #4338CA;
            --success-color: #059669;
            --danger-color: #DC2626;
            --warning-color: #D97706;
            --background-color: #F3F4F6;
            --text-primary: #111827;
            --text-secondary: #4B5563;
            --border-color: #E5E7EB;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background-color);
            color: var(--text-primary);
            line-height: 1.5;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: white;
            border-right: 1px solid var(--border-color);
            padding: 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: transform 0.3s ease;
        }

        .sidebar-header {
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 1.5rem;
        }

        .sidebar-logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: 0.5rem;
            transition: all 0.2s ease;
        }

        .nav-link i {
            margin-right: 0.75rem;
            font-size: 1.25rem;
        }

        .nav-link:hover, .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }

        .nav-link.danger {
            color: var(--danger-color);
        }

        .nav-link.danger:hover {
            background-color: var(--danger-color);
            color: white;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .welcome-text {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .stat-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .stat-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
        }

        .stat-icon.products {
            background-color: rgba(79, 70, 229, 0.1);
            color: var(--primary-color);
        }

        .stat-icon.orders {
            background-color: rgba(5, 150, 105, 0.1);
            color: var(--success-color);
        }

        .stat-title {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .stat-value {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        /* Dashboard Sections */
        .dashboard-section {
            background: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        /* Tables */
        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
        }

        .dashboard-table th,
        .dashboard-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .dashboard-table th {
            font-weight: 500;
            color: var(--text-secondary);
            background-color: #F9FAFB;
        }

        .dashboard-table tr:hover {
            background-color: #F9FAFB;
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        .status-badge.completed {
            background-color: rgba(5, 150, 105, 0.1);
            color: var(--success-color);
        }

        .status-badge.pending {
            background-color: rgba(217, 119, 6, 0.1);
            color: var(--warning-color);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 50;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
        }

        /* Dark Mode */
        .dark-mode {
            --background-color: #111827;
            --text-primary: #F9FAFB;
            --text-secondary: #D1D5DB;
            --border-color: #374151;
        }

        .dark-mode .sidebar,
        .dark-mode .stat-card,
        .dark-mode .dashboard-section {
            background-color: #1F2937;
        }

        .dark-mode .dashboard-table th {
            background-color: #374151;
        }

        .dark-mode .dashboard-table tr:hover {
            background-color: #374151;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-logo">AdminPanel</a>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link active">
                            <i class="ri-dashboard-line"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="add_product.php" class="nav-link">
                            <i class="ri-add-circle-line"></i>
                            Add Product
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="manage_products.php" class="nav-link">
                            <i class="ri-shopping-bag-line"></i>
                            Manage Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="data_monitoring.php" class="nav-link">
                            <i class="ri-line-chart-line"></i>
                            Data Monitoring
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="sales_management.php" class="nav-link">
                            <i class="ri-money-dollar-circle-line"></i>
                            Sales Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="customer_management.php" class="nav-link">
                            <i class="ri-user-line"></i>
                            Customer Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="customer_report.php" class="nav-link">
                            <i class="ri-file-list-line"></i>
                            Customer Report
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../logout.php" class="nav-link danger">
                            <i class="ri-logout-box-line"></i>
                            Logout
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="page-header">
                <h1 class="welcome-text">Welcome, <?php echo isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name']) : 'Admin'; ?>!</h1>
                <button class="theme-toggle" onclick="toggleDarkMode()">
                    <i class="ri-moon-line" id="themeIcon"></i>
                </button>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon products">
                            <i class="ri-shopping-bag-line"></i>
                        </div>
                        <div>
                            <div class="stat-title">Total Products</div>
                            <div class="stat-value"><?php echo number_format($totalProducts); ?></div>
                        </div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon orders">
                            <i class="ri-shopping-cart-line"></i>
                        </div>
                        <div>
                            <div class="stat-title">Total Orders</div>
                            <div class="stat-value"><?php echo number_format($totalOrders); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2 class="section-title">Recent Orders</h2>
                </div>
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                            <td>$<?php echo number_format($order['total_cost'], 2); ?></td>
                            <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                            <td>
                                <span class="status-badge completed">Completed</span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Top Products -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2 class="section-title">Top Products</h2>
                </div>
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Orders</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topProducts as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo number_format($product['order_count']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Dark Mode Toggle
        function toggleDarkMode() {
            const body = document.body;
            const themeIcon = document.getElementById('themeIcon');
            body.classList.toggle('dark-mode');
            
            if (body.classList.contains('dark-mode')) {
                themeIcon.className = 'ri-sun-line';
                localStorage.setItem('darkMode', 'enabled');
            } else {
                themeIcon.className = 'ri-moon-line';
                localStorage.setItem('darkMode', 'disabled');
            }
        }

        // Check saved theme preference
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark-mode');
            document.getElementById('themeIcon').className = 'ri-sun-line';
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const toggleButton = document.getElementById('toggleSidebar');
            
            if (window.innerWidth <= 1024 && 
                !sidebar.contains(event.target) && 
                !toggleButton.contains(event.target)) {
                sidebar.classList.remove('show');
            }
        });

        // Chart.js initialization
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Products', 'Orders'],
                datasets: [{
                    label: 'Statistics',
                    data: [<?php echo $totalProducts; ?>, <?php echo $totalOrders; ?>],
                    backgroundColor: [
                        'rgba(79, 70, 229, 0.8)',
                        'rgba(5, 150, 105, 0.8)'
                    ],
                    borderColor: [
                        'rgba(79, 70, 229, 1)',
                        'rgba(5, 150, 105, 1)'
                    ],
                    borderWidth: 2,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Update chart colors in dark mode
        function updateChartColors(isDark) {
            salesChart.options.scales.y.grid.color = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
            salesChart.update();
        }
    </script>
</body>
</html>