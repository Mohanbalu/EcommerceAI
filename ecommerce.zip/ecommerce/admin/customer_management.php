<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Enhance session security
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6;
            color: #1f2937;
            line-height: 1.6;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 2rem auto;
            background-color: #ffffff;
            padding: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
        }

        h2 {
            text-align: center;
            color: #111827;
            font-size: 1.875rem;
            margin-bottom: 2rem;
            font-weight: 600;
        }

        nav {
            background-color: #1f2937;
            padding: 1rem 2rem;
            margin-bottom: 2rem;
        }

        nav a {
            color: #ffffff;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            display: inline-block;
            margin-right: 1rem;
        }

        nav a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .table-container {
            overflow-x: auto;
            margin-top: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background-color: #ffffff;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        th {
            background-color: #f9fafb;
            color: #4b5563;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
            white-space: nowrap;
        }

        tr:hover td {
            background-color: #f9fafb;
        }

        td {
            color: #4b5563;
            font-size: 0.875rem;
        }

        .actions {
            display: flex;
            gap: 0.5rem;
            white-space: nowrap;
        }

        .action-btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .edit-btn {
            background-color: #3b82f6;
            color: white;
        }

        .edit-btn:hover {
            background-color: #2563eb;
        }

        .copy-btn {
            background-color: #10b981;
            color: white;
        }

        .copy-btn:hover {
            background-color: #059669;
        }

        .delete-btn {
            background-color: #ef4444;
            color: white;
        }

        .delete-btn:hover {
            background-color: #dc2626;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #6b7280;
        }

        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .alert.success {
            background-color: #dcfce7;
            color: #166534;
        }

        .alert.error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 1rem;
            }

            nav {
                padding: 1rem;
            }

            nav a {
                display: block;
                margin-bottom: 0.5rem;
            }

            .actions {
                flex-direction: column;
            }

            .action-btn {
                width: 100%;
                text-align: center;
                margin-bottom: 0.25rem;
            }
        }
    </style>
</head>
<body>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="customer_management.php" style="background-color: rgba(255, 255, 255, 0.1);">Customers</a>
        <a href="products.php">Products</a>
        <a href="data_monitoring.php">Monitoring</a>
    </nav>

    <div class="container">
        <h2>Customer Management</h2>

        <?php if (isset($_GET['delete_id']) || isset($_GET['copy_id'])): ?>
            <div class="alert <?php echo isset($_GET['delete_id']) ? 'success' : 'info'; ?>">
                <?php echo isset($_GET['delete_id']) ? 'Customer deleted successfully!' : 'Customer copied successfully!'; ?>
            </div>
        <?php endif; ?>

        <div class="table-container">
            <?php
            // Fetching customers except for admin users
            $stmt = $conn->prepare("SELECT id, username, email, phone, address, created_at, full_name, pincode, location, profile_picture FROM users WHERE role != 'admin'");
            $stmt->execute();
            $customers = $stmt->fetchAll();

            if ($customers): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $customer): ?>
                            <tr>
                                <td><?= htmlspecialchars($customer['full_name'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars($customer['email'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars($customer['phone'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars($customer['address'], ENT_QUOTES, 'UTF-8') ?></td>
                                <td>
                                    <div class="actions">
                                        <a href="edit_customer.php?id=<?= $customer['id'] ?>" class="action-btn edit-btn">Edit</a>
                                        <a href="?copy_id=<?= $customer['id'] ?>" class="action-btn copy-btn">Copy</a>
                                        <a href="?delete_id=<?= $customer['id'] ?>" 
                                           onclick="return confirm('Are you sure you want to delete this customer?')" 
                                           class="action-btn delete-btn">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <p>No customers found.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php
    // Handle customer deletion
    if (isset($_GET['delete_id'])) {
        $delete_id = $_GET['delete_id'];
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$delete_id]);
        header("Location: customer_management.php");
    }

    // Handle copying customer data
    if (isset($_GET['copy_id'])) {
        $copy_id = $_GET['copy_id'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$copy_id]);
        $customer = $stmt->fetch();

        if ($customer) {
            $stmt = $conn->prepare("INSERT INTO users (username, email, phone, address, created_at, role, full_name, pincode, location, profile_picture) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $customer['username'],
                $customer['email'],
                $customer['phone'],
                $customer['address'],
                $customer['created_at'],
                'user',
                $customer['full_name'],
                $customer['pincode'],
                $customer['location'],
                $customer['profile_picture']
            ]);
            header("Location: customer_management.php");
        }
    }
    ?>
</body>
</html>