<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$stmt = $conn->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4CAF50;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --light: #f8f9fa;
            --dark: #212529;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 8px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7fa;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .header {
            background: white;
            padding: 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h2 {
            color: var(--dark);
            font-size: 1.75rem;
            font-weight: 600;
            margin: 0;
        }

        .add-product-btn {
            background: var(--primary);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
        }

        .add-product-btn:hover {
            background: var(--secondary);
            transform: translateY(-2px);
        }

        .table-container {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: var(--light);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--dark);
            border-bottom: 2px solid #dee2e6;
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            vertical-align: middle;
        }

        tr:hover {
            background-color: rgba(67, 97, 238, 0.05);
        }

        .product-image {
            width: 60px;
            height: 60px;
            border-radius: var(--radius);
            object-fit: cover;
            box-shadow: var(--shadow);
        }

        .stock-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        .stock-positive {
            background: rgba(76, 175, 80, 0.1);
            color: var(--success);
        }

        .stock-negative {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .stock-warning {
            background: rgba(255, 193, 7, 0.1);
            color: var(--warning);
        }

        .actions {
            display: flex;
            gap: 0.5rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-edit {
            background: rgba(67, 97, 238, 0.1);
            color: var(--primary);
        }

        .btn-edit:hover {
            background: var(--primary);
            color: white;
        }

        .btn-delete {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: white;
        }

        .stock-history {
            font-size: 0.875rem;
            color: var(--dark);
            opacity: 0.8;
        }

        .stock-change {
            display: inline-block;
            padding: 0.125rem 0.375rem;
            border-radius: 4px;
            margin: 0.125rem 0;
        }

        .stock-increase {
            background: rgba(76, 175, 80, 0.1);
            color: var(--success);
        }

        .stock-decrease {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .back-btn {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            background: var(--primary);
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .back-btn:hover {
            transform: translateY(-3px);
            background: var(--secondary);
        }

        @media (max-width: 1024px) {
            .container {
                padding: 1rem;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Manage Products</h2>
            <a href="add_product.php" class="add-product-btn">
                <i class="fas fa-plus"></i>
                Add New Product
            </a>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Category</th>
                        <th>SKU</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product) : ?>
                        <tr>
                            <td>
                                <img src="../product_images/<?= htmlspecialchars($product['image']); ?>" 
                                     alt="<?= htmlspecialchars($product['name']); ?>" 
                                     class="product-image">
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($product['name']); ?></strong>
                                <div style="font-size: 0.875rem; color: #666;">
                                    <?= substr(htmlspecialchars($product['description']), 0, 50) . '...'; ?>
                                </div>
                            </td>
                            <td>
                                <strong>$<?= number_format($product['price'], 2); ?></strong>
                            </td>
                            <td>
                                <?php
                                    $stockClass = '';
                                    if ($product['stock'] > 20) {
                                        $stockClass = 'stock-positive';
                                    } elseif ($product['stock'] > 5) {
                                        $stockClass = 'stock-warning';
                                    } else {
                                        $stockClass = 'stock-negative';
                                    }
                                ?>
                                <span class="stock-badge <?= $stockClass ?>">
                                    <?= $product['stock']; ?> units
                                </span>
                                <div class="stock-history">
                                    <?php
                                        $stockStmt = $conn->prepare("SELECT change_amount, action, change_date FROM stock_movements WHERE product_id = :product_id ORDER BY change_date DESC LIMIT 3");
                                        $stockStmt->bindParam(':product_id', $product['id']);
                                        $stockStmt->execute();
                                        $stockMovements = $stockStmt->fetchAll(PDO::FETCH_ASSOC);

                                        foreach ($stockMovements as $movement) {
                                            $changeClass = $movement['change_amount'] > 0 ? 'stock-increase' : 'stock-decrease';
                                            echo '<div class="stock-change ' . $changeClass . '">';
                                            echo ($movement['change_amount'] > 0 ? '+' : '') . $movement['change_amount'];
                                            echo ' (' . $movement['action'] . ')';
                                            echo '</div>';
                                        }
                                    ?>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($product['category']); ?></td>
                            <td><?= htmlspecialchars($product['sku']); ?></td>
                            <td class="actions">
                                <a href="edit_product.php?id=<?= $product['id']; ?>" class="btn btn-edit">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </a>
                                <a href="delete_product.php?id=<?= $product['id']; ?>" 
                                   class="btn btn-delete"
                                   onclick="return confirm('Are you sure you want to delete this product?')">
                                    <i class="fas fa-trash"></i>
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="dashboard.php" class="back-btn">
        <i class="fas fa-arrow-left"></i>
    </a>
</body>
</html>