<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Function to generate SKU based on the product category
function generateSKU($category) {
    $categoryCode = strtoupper(substr($category, 0, 3)); // Take first 3 letters
    return $categoryCode . '-' . strtoupper(dechex(time())) . rand(100, 9999); // Add timestamp + random number
}

if (isset($_POST['add_product'])) {
    // Capture form inputs
    $name = htmlspecialchars($_POST['name']);
    $price = $_POST['price'];
    $description = htmlspecialchars($_POST['description']);
    $stock = $_POST['stock'];
    $category = htmlspecialchars($_POST['category']);
    
    // Generate SKU automatically
    $sku = generateSKU($category);

    $image = $_FILES['image']['name'];
    // Collect the dynamic attributes depending on category
    $attributes = [];

    // Dynamically adding attributes based on the selected category
    if ($category == "Laptops") {
        $attributes = [
            "specialization" => $_POST['specialization'],
            "processor" => $_POST['processor'],
            "ram" => $_POST['ram'],
            "rom" => $_POST['rom']
        ];
    } elseif ($category == "Fruits") {
        $attributes = [
            "weight" => $_POST['weight'],
            "organic" => $_POST['organic']
        ];
    } elseif ($category == "Electrical Gadgets") {
        $attributes = [
            "power_rating" => $_POST['power_rating'],
            "warranty_period" => $_POST['warranty_period']
        ];
    } elseif ($category == "Phones") {
        $attributes = [
            "processor" => $_POST['processor'],
            "ram" => $_POST['ram'],
            "battery" => $_POST['battery']
        ];
    } elseif ($category == "Furniture") {
        $attributes = [
            "material" => $_POST['material'],
            "dimensions" => $_POST['dimensions']
        ];
    } elseif ($category == "Books") {
        $attributes = [
            "author" => $_POST['author'],
            "isbn" => $_POST['isbn']
        ];
    }

    // Convert attributes array to JSON
    $attributesJson = json_encode($attributes);

    // Move uploaded image to the images directory
    if (!empty($image)) {
        $imagePath = "../product_images/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    // Prepare and execute the SQL query to insert the product
    $stmt = $conn->prepare("INSERT INTO products (name, price, description, image, stock, category, sku, attributes) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $price, $description, $image, $stock, $category, $sku, $attributesJson]);

    // Success message
    $successMessage = "Product added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .form-section {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.3s ease-out;
        }
        
        .form-section.active {
            opacity: 1;
            transform: translateY(0);
        }

        .custom-file-input::-webkit-file-upload-button {
            visibility: hidden;
        }

        .custom-file-input::before {
            content: 'Select Image';
            display: inline-block;
            background: #4F46E5;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4F46E5;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            height: 4px;
            background: #4F46E5;
            transition: width 0.3s ease;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="progress-bar" id="progressBar"></div>
    
    <?php if(isset($successMessage)): ?>
    <div class="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded shadow-lg" id="successMessage">
        <?php echo $successMessage; ?>
    </div>
    <?php endif; ?>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div class="bg-indigo-600 px-6 py-4">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold text-white">Add New Product</h2>
                    <a href="dashboard.php" class="bg-white text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-50 transition-colors">
                        Back to Dashboard
                    </a>
                </div>
            </div>

            <form method="POST" enctype="multipart/form-data" class="p-6 space-y-6" id="productForm">
                <!-- Basic Information Section -->
                <div class="form-section active">
                    <h3 class="text-lg font-semibold text-gray-700 mb-4">Basic Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Product Name</label>
                            <input type="text" name="name" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Price</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <span class="text-gray-500 sm:text-sm">$</span>
                                </div>
                                <input type="number" name="price" step="0.01" required
                                    class="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea name="description" rows="3" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Stock</label>
                            <input type="number" name="stock" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Category</label>
                            <select name="category" required onchange="showAdditionalFields()"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                <option value="">Select a category</option>
                                <option value="Dresses">Dresses</option>
                                <option value="Phones">Phones</option>
                                <option value="Laptops">Laptops</option>
                                <option value="Accessories">Accessories</option>
                                <option value="Books">Books</option>
                                <option value="Furniture">Furniture</option>
                                <option value="Digital Services">Digital Services</option>
                                <option value="Cosmetics">Cosmetics and Body Care</option>
                                <option value="Food">Food and Beverage</option>
                                <option value="Health">Health and Wellness</option>
                                <option value="Household">Household Items</option>
                                <option value="Media">Media</option>
                                <option value="Pet">Pet Care</option>
                                <option value="Office">Office Equipment</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Category Specific Fields -->
                <div id="categoryFields" class="form-section space-y-6">
                    <!-- Dynamic fields will be inserted here -->
                </div>

                <!-- Image Upload Section -->
                <div class="form-section active">
                    <h3 class="text-lg font-semibold text-gray-700 mb-4">Product Image</h3>
                    <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        <div class="space-y-1 text-center">
                            <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <div class="flex text-sm text-gray-600">
                                <label class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                    <span>Upload a file</span>
                                    <input type="file" name="image" class="sr-only" required accept="image/*">
                                </label>
                                <p class="pl-1">or drag and drop</p>
                            </div>
                            <p class="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="button" onclick="window.location.href='dashboard.php'" 
                        class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Cancel
                    </button>
                    <button type="submit" name="add_product"
                        class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Add Product
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Show loading state
        function showLoading() {
            const loading = document.createElement('div');
            loading.className = 'loading';
            loading.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loading);
        }

        // Update progress bar
        function updateProgress(percent) {
            document.getElementById('progressBar').style.width = percent + '%';
        }

        // Handle form submission
        document.getElementById('productForm').addEventListener('submit', function(e) {
            showLoading();
            updateProgress(0);
            
            // Simulate progress (in a real application, this would be based on actual upload progress)
            let progress = 0;
            const interval = setInterval(() => {
                progress += 5;
                if (progress <= 90) {
                    updateProgress(progress);
                }
            }, 100);
        });

        // Handle success message dismissal
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.opacity = '0';
                setTimeout(() => successMessage.remove(), 300);
            }, 3000);
        }

        // Category-specific fields
        const categoryFields = {
            Dresses: [
                { name: 'material', label: 'Material' },
                { name: 'size', label: 'Size' },
                { name: 'color', label: 'Color' },
                { name: 'brand', label: 'Brand' },
                { name: 'pattern', label: 'Pattern' },
                { name: 'sleeve_length', label: 'Sleeve Length' }
            ],
            Phones: [
                { name: 'processor', label: 'Processor' },
                { name: 'ram', label: 'RAM' },
                { name: 'storage', label: 'Storage' },
                { name: 'battery', label: 'Battery' },
                { name: 'display_size', label: 'Display Size' },
                { name: 'camera', label: 'Camera' },
                { name: 'os', label: 'Operating System' }
            ],
            // Add more categories as needed
        };

        function showAdditionalFields() {
            const category = document.querySelector('select[name="category"]').value;
            const container = document.getElementById('categoryFields');
            container.innerHTML = '';

            if (categoryFields[category]) {
                const fields = categoryFields[category];
                const grid = document.createElement('div');
                grid.className = 'grid grid-cols-1 md:grid-cols-2 gap-6';

                fields.forEach(field => {
                    const div = document.createElement('div');
                    div.innerHTML = `
                        <label class="block text-sm font-medium text-gray-700">${field.label}</label>
                        <input type="text" name="${field.name}"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    `;
                    grid.appendChild(div);
                });

                container.appendChild(grid);
            }
        }

        // Initialize form sections
        document.querySelectorAll('.form-section').forEach((section, index) => {
            setTimeout(() => {
                section.classList.add('active');
            }, index * 100);
        });
    </script>
</body>
</html>