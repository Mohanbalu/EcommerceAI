<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Function to generate SKU based on the product category
function generateSKU($category) {
    $categoryCode = strtoupper(substr($category, 0, 3)); // Take first 3 letters
    return $categoryCode . '-' . strtoupper(dechex(time())) . rand(100, 9999); // Add timestamp + random number
}

if (isset($_POST['add_product'])) {
    // Capture form inputs
    $name = htmlspecialchars($_POST['name']);
    $price = $_POST['price'];
    $description = htmlspecialchars($_POST['description']);
    $stock = $_POST['stock'];
    $category = htmlspecialchars($_POST['category']);
    
    // Generate SKU automatically
    $sku = generateSKU($category);

    $image = $_FILES['image']['name'];
    // Collect the dynamic attributes depending on category
    $attributes = [];

    // Dynamically adding attributes based on the selected category
    if ($category == "Laptops") {
        $attributes = [
            "specialization" => $_POST['specialization'],
            "processor" => $_POST['processor'],
            "ram" => $_POST['ram'],
            "rom" => $_POST['rom']
        ];
    } elseif ($category == "Fruits") {
        $attributes = [
            "weight" => $_POST['weight'],
            "organic" => $_POST['organic']
        ];
    } elseif ($category == "Electrical Gadgets") {
        $attributes = [
            "power_rating" => $_POST['power_rating'],
            "warranty_period" => $_POST['warranty_period']
        ];
    } elseif ($category == "Phones") {
        $attributes = [
            "processor" => $_POST['processor'],
            "ram" => $_POST['ram'],
            "battery" => $_POST['battery']
        ];
    } elseif ($category == "Furniture") {
        $attributes = [
            "material" => $_POST['material'],
            "dimensions" => $_POST['dimensions']
        ];
    } elseif ($category == "Books") {
        $attributes = [
            "author" => $_POST['author'],
            "isbn" => $_POST['isbn']
        ];
    }

    // Convert attributes array to JSON
    $attributesJson = json_encode($attributes);

    // Move uploaded image to the images directory
    if (!empty($image)) {
        $imagePath = "../product_images/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    }

    // Prepare and execute the SQL query to insert the product
    $stmt = $conn->prepare("INSERT INTO products (name, price, description, image, stock, category, sku, attributes) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $price, $description, $image, $stock, $category, $sku, $attributesJson]);

    // Success message
    $successMessage = "Product added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 10px 0 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"], input[type="number"], textarea, input[type="file"], select {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .message {
            color: green;
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        .back-link a {
            color: #4CAF50;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="name">Product Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="price">Price:</label>
            <input type="number" step="0.01" name="price" id="price" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" required></textarea>

            <label for="stock">Stock:</label>
            <input type="number" name="stock" id="stock" required>

            <label for="category">Category:</label>
  <select name="category" id="category" required onchange="showAdditionalFields()">
    <option value="Dresses">Dresses</option>
    <option value="Phones">Phones</option>
    <option value="Laptops">Laptops</option>
    <option value="Accessories">Accessories</option>
    <option value="Books">Books</option>
    <option value="Furniture">Furniture</option>
    <option value="Digital Services">Digital Services</option>
    <option value="Cosmetics and Body Care">Cosmetics and Body Care</option>
    <option value="Food and Beverage">Food and Beverage</option>
    <option value="Health and Wellness">Health and Wellness</option>
    <option value="Household Items">Household Items</option>
    <option value="Media">Media</option>
    <option value="Pet Care">Pet Care</option>
    <option value="Office Equipment">Office Equipment</option>
  </select>
            <label for="sku">SKU (auto-generated):</label>
            <input type="text" name="sku" id="sku" value="<?php echo $sku ?? ''; ?>" disabled>

            <label for="image">Image:</label>
            <input type="file" name="image" id="image" required>

            <div id="dresses_fields" style="display:none;">
    <label for="material">Material:</label>
    <input type="text" name="material" id="material"><br>
    <label for="size">Size:</label>
    <input type="text" name="size" id="size"><br>
    <label for="color">Color:</label>
    <input type="text" name="color" id="color"><br>
    <label for="brand">Brand:</label>
    <input type="text" name="brand" id="brand"><br>
    <label for="pattern">Pattern:</label>
    <input type="text" name="pattern" id="pattern"><br>
    <label for="sleeve_length">Sleeve Length:</label>
    <input type="text" name="sleeve_length" id="sleeve_length"><br>
  </div>

  <!-- Additional Fields for Phones -->
  <div id="phones_fields" style="display:none;">
    <label for="processor">Processor:</label>
    <input type="text" name="processor" id="processor"><br>
    <label for="ram">RAM:</label>
    <input type="text" name="ram" id="ram"><br>
    <label for="rom">ROM:</label>
    <input type="text" name="rom" id="rom"><br>
    <label for="battery">Battery:</label>
    <input type="text" name="battery" id="battery"><br>
    <label for="display_size">Display Size:</label>
    <input type="text" name="display_size" id="display_size"><br>
    <label for="camera">Camera:</label>
    <input type="text" name="camera" id="camera"><br>
    <label for="os">Operating System:</label>
    <input type="text" name="os" id="os"><br>
  </div>

  <!-- Additional Fields for Laptops -->
  <div id="laptops_fields" style="display:none;">
    <label for="processor">Processor:</label>
    <input type="text" name="processor" id="processor"><br>
    <label for="ram">RAM:</label>
    <input type="text" name="ram" id="ram"><br>
    <label for="storage">ROM (Storage):</label>
    <input type="text" name="storage" id="storage"><br>
    <label for="specialization">Specialization:</label>
    <input type="text" name="specialization" id="specialization"><br>
    <label for="screen_size">Screen Size:</label>
    <input type="text" name="screen_size" id="screen_size"><br>
    <label for="battery_life">Battery Life:</label>
    <input type="text" name="battery_life" id="battery_life"><br>
    <label for="os">Operating System:</label>
    <input type="text" name="os" id="os"><br>
  </div>

  <!-- Additional Fields for Accessories -->
  <div id="accessories_fields" style="display:none;">
    <label for="type">Type:</label>
    <input type="text" name="type" id="type"><br>
    <label for="material">Material:</label>
    <input type="text" name="material" id="material"><br>
    <label for="compatibility">Compatibility:</label>
    <input type="text" name="compatibility" id="compatibility"><br>
    <label for="color">Color:</label>
    <input type="text" name="color" id="color"><br>
    <label for="brand">Brand:</label>
    <input type="text" name="brand" id="brand"><br>
  </div>

  <!-- Additional Fields for Books -->
  <div id="books_fields" style="display:none;">
    <label for="author">Author:</label>
    <input type="text" name="author" id="author"><br>
    <label for="isbn">ISBN:</label>
    <input type="text" name="isbn" id="isbn"><br>
    <label for="genre">Genre:</label>
    <input type="text" name="genre" id="genre"><br>
    <label for="publisher">Publisher:</label>
    <input type="text" name="publisher" id="publisher"><br>
    <label for="edition">Edition:</label>
    <input type="text" name="edition" id="edition"><br>
    <label for="language">Language:</label>
    <input type="text" name="language" id="language"><br>
  </div>
<!-- Additional Fields for Furniture -->
<div id="furniture_fields" style="display:none;">
  <label for="material">Material:</label>
  <input type="text" name="material" id="material"><br>
  <label for="dimensions">Dimensions:</label>
  <input type="text" name="dimensions" id="dimensions"><br>
  <label for="style">Style:</label>
  <input type="text" name="style" id="style"><br>
  <label for="weight">Weight:</label>
  <input type="text" name="weight" id="weight"><br>
  <label for="assembly_required">Assembly Required:</label>
  <input type="text" name="assembly_required" id="assembly_required"><br>
  <label for="color">Color:</label>
  <input type="text" name="color" id="color"><br>
</div>

<!-- Additional Fields for Digital Services -->
<div id="digital_services_fields" style="display:none;">
  <label for="service_type">Type of Service:</label>
  <input type="text" name="service_type" id="service_type"><br>
  <label for="duration">Duration:</label>
  <input type="text" name="duration" id="duration"><br>
  <label for="platform_compatibility">Platform Compatibility:</label>
  <input type="text" name="platform_compatibility" id="platform_compatibility"><br>
  <label for="license_type">License Type:</label>
  <input type="text" name="license_type" id="license_type"><br>
  <label for="renewal_option">Renewal Option:</label>
  <input type="text" name="renewal_option" id="renewal_option"><br>
</div>

<!-- Additional Fields for Cosmetics and Body Care -->
<div id="cosmetics_body_care_fields" style="display:none;">
  <label for="type">Type:</label>
  <input type="text" name="type" id="type"><br>
  <label for="ingredients">Ingredients:</label>
  <input type="text" name="ingredients" id="ingredients"><br>
  <label for="skin_type">Skin Type:</label>
  <input type="text" name="skin_type" id="skin_type"><br>
  <label for="brand">Brand:</label>
  <input type="text" name="brand" id="brand"><br>
  <label for="volume">Volume:</label>
  <input type="text" name="volume" id="volume"><br>
  <label for="expiry_date">Expiry Date:</label>
  <input type="text" name="expiry_date" id="expiry_date"><br>
</div>

<!-- Additional Fields for Food and Beverage -->
<div id="food_beverage_fields" style="display:none;">
  <label for="weight">Weight:</label>
  <input type="text" name="weight" id="weight"><br>
  <label for="ingredients">Ingredients:</label>
  <input type="text" name="ingredients" id="ingredients"><br>
  <label for="expiry_date">Expiry Date:</label>
  <input type="text" name="expiry_date" id="expiry_date"><br>
  <label for="storage_instructions">Storage Instructions:</label>
  <input type="text" name="storage_instructions" id="storage_instructions"><br>
  <label for="dietary_info">Dietary Info:</label>
  <input type="text" name="dietary_info" id="dietary_info"><br>
</div>

<!-- Additional Fields for Health and Wellness -->
<div id="health_wellness_fields" style="display:none;">
  <label for="product_type">Product Type:</label>
  <input type="text" name="product_type" id="product_type"><br>
  <label for="ingredients">Ingredients:</label>
  <input type="text" name="ingredients" id="ingredients"><br>
  <label for="brand">Brand:</label>
  <input type="text" name="brand" id="brand"><br>
  <label for="dosage">Dosage:</label>
  <input type="text" name="dosage" id="dosage"><br>
  <label for="side_effects">Side Effects:</label>
  <input type="text" name="side_effects" id="side_effects"><br>
</div>

<!-- Additional Fields for Household Items -->
<div id="household_items_fields" style="display:none;">
  <label for="item_type">Type of Item:</label>
  <input type="text" name="item_type" id="item_type"><br>
  <label for="material">Material:</label>
  <input type="text" name="material" id="material"><br>
  <label for="brand">Brand:</label>
  <input type="text" name="brand" id="brand"><br>
  <label for="weight">Weight:</label>
  <input type="text" name="weight" id="weight"><br>
  <label for="dimensions">Dimensions:</label>
  <input type="text" name="dimensions" id="dimensions"><br>
</div>

<!-- Additional Fields for Media -->
<div id="media_fields" style="display:none;">
  <label for="type">Type:</label>
  <input type="text" name="type" id="type"><br>
  <label for="genre">Genre:</label>
  <input type="text" name="genre" id="genre"><br>
  <label for="release_date">Release Date:</label>
  <input type="text" name="release_date" id="release_date"><br>
  <label for="duration">Duration:</label>
  <input type="text" name="duration" id="duration"><br>
  <label for="rating">Rating:</label>
  <input type="text" name="rating" id="rating"><br>
</div>

<!-- Additional Fields for Pet Care -->
<div id="pet_care_fields" style="display:none;">
  <label for="product_type">Product Type:</label>
  <input type="text" name="product_type" id="product_type"><br>
  <label for="breed_suitability">Breed Suitability:</label>
  <input type="text" name="breed_suitability" id="breed_suitability"><br>
  <label for="material">Material:</label>
  <input type="text" name="material" id="material"><br>
  <label for="size">Size:</label>
  <input type="text" name="size" id="size"><br>
  <label for="brand">Brand:</label>
  <input type="text" name="brand" id="brand"><br>
</div>

<!-- Additional Fields for Office Equipment -->
<div id="office_equipment_fields" style="display:none;">
  <label for="equipment_type">Type of Equipment:</label>
  <input type="text" name="equipment_type" id="equipment_type"><br>
  <label for="material">Material:</label>
  <input type="text" name="material" id="material"><br>
  <label for="dimensions">Size/Dimensions:</label>
  <input type="text" name="dimensions" id="dimensions"><br>
  <label for="weight">Weight:</label>
  <input type="text" name="weight" id="weight"><br>
  <label for="warranty">Warranty Period:</label>
  <input type="text" name="warranty" id="warranty"><br>
  <label for="brand">Brand:</label>
  <input type="text" name="brand" id="brand"><br>
</div>

            <button type="submit" name="add_product">Add Product</button>
        </form>
    </div>
</body>
<script>
       function showAdditionalFields() {
  // Hide all fields first
  var allFields = document.querySelectorAll('[id$="_fields"]');
  allFields.forEach(function(field) {
    field.style.display = "none";
  });

  // Get the selected category
  var category = document.getElementById('category').value;

  // Show corresponding fields
  var categoryFields = document.getElementById(category.toLowerCase() + '_fields');
  if (categoryFields) {
    categoryFields.style.display = "block";
  }
}

    </script>
</html>
