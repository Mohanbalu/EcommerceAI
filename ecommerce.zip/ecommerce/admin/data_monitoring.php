<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

// Fetch data with prepared statement
$query = "
SELECT 
    p.id,
    p.name AS product_name,
    p.stock AS current_stock,
    IFNULL(SUM(od.quantity), 0) AS total_sold,
    p.stock + IFNULL(SUM(od.quantity), 0) AS initial_stock
FROM products p
LEFT JOIN order_details od ON p.id = od.product_id
GROUP BY p.id, p.name, p.stock
ORDER BY p.name ASC";

try {
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Monitoring</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f5f7fa;
            color: #1a1a1a;
            line-height: 1.6;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 2rem auto;
            background-color: #ffffff;
            padding: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
        }

        h2 {
            text-align: center;
            color: #2d3748;
            font-size: 2rem;
            margin-bottom: 2rem;
            font-weight: 600;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: #f8fafc;
            padding: 1.5rem;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }

        .stat-card h3 {
            color: #64748b;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }

        .stat-card p {
            color: #1a1a1a;
            font-size: 1.5rem;
            font-weight: 600;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 1.5rem;
            background: #ffffff;
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            text-align: left;
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }

        table th {
            background-color: #f8fafc;
            color: #64748b;
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }

        table tr:hover {
            background-color: #f8fafc;
            transition: background-color 0.2s ease;
        }

        table td {
            color: #4a5568;
        }

        .btn-back {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background-color: #3b82f6;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-top: 2rem;
        }

        .btn-back:hover {
            background-color: #2563eb;
            transform: translateY(-1px);
        }

        nav {
            background-color: #1a1a1a;
            padding: 1rem 2rem;
            margin-bottom: 2rem;
        }

        nav a {
            color: #ffffff;
            text-decoration: none;
            font-size: 0.875rem;
            margin-right: 1.5rem;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: all 0.2s ease;
        }

        nav a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .status-low {
            background-color: #fee2e2;
            color: #dc2626;
        }

        .status-good {
            background-color: #dcfce7;
            color: #16a34a;
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 1rem;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="data_monitoring.php" style="background-color: rgba(255, 255, 255, 0.1);">Monitoring</a>
    </nav>

    <div class="container">
        <h2>Data Monitoring</h2>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Products</h3>
                <p><?= count($products) ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Items Sold</h3>
                <p><?= array_sum(array_column($products, 'total_sold')) ?></p>
            </div>
            <div class="stat-card">
                <h3>Current Stock</h3>
                <p><?= array_sum(array_column($products, 'current_stock')) ?></p>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product Name</th>
                    <th>Initial Stock</th>
                    <th>Total Sold</th>
                    <th>Current Stock</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($products) > 0): ?>
                    <?php $index = 1; ?>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= htmlspecialchars($index++) ?></td>
                            <td><?= htmlspecialchars($product['product_name']) ?></td>
                            <td><?= htmlspecialchars($product['initial_stock']) ?></td>
                            <td><?= htmlspecialchars($product['total_sold']) ?></td>
                            <td><?= htmlspecialchars($product['current_stock']) ?></td>
                            <td>
                                <?php
                                $stockStatus = $product['current_stock'] < 10 ? 
                                    '<span class="status-badge status-low">Low Stock</span>' : 
                                    '<span class="status-badge status-good">In Stock</span>';
                                echo $stockStatus;
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">No data available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
    </div>
</body>
</html>