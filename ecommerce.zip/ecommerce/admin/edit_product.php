<?php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$product_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$product_id) {
    header("Location: manage_products.php");
    exit();
}

// Fetch the product details
$stmt = $conn->prepare("SELECT * FROM products WHERE id = :id");
$stmt->bindParam(':id', $product_id);
$stmt->execute();
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    echo "Product not found.";
    exit();
}

// Categories available in your inventory
$categories = ['Dresses', 'Phones', 'Laptops', 'Accessories', 'Books', 'Furniture'];

// Function to generate SKU
function generateSKU($category) {
    // Strip spaces and get the first three letters for category code
    $categoryCode = strtoupper(substr($category, 0, 3));
    // Generate a random number or combine with product ID for uniqueness
    return $categoryCode . '-' . strtoupper(dechex(time())) . rand(100, 9999);
}

// Update product details when the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $stock = $_POST['stock'];
    $category = $_POST['category'];
    $sku = generateSKU($category); // Automatically generate SKU based on category
    $image = $_FILES['image']['name'];
    $imageTmp = $_FILES['image']['tmp_name'];

    // Image upload
    if ($image) {
        $imagePath = "../product_images/" . basename($image);
        move_uploaded_file($imageTmp, $imagePath);
    } else {
        $imagePath = $product['image']; // Keep the old image if no new one is uploaded
    }

    // Update the product in the database
    $stmt = $conn->prepare("UPDATE products SET name = :name, price = :price, description = :description, stock = :stock, category = :category, sku = :sku, image = :image WHERE id = :id");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':stock', $stock);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':sku', $sku);
    $stmt->bindParam(':image', $imagePath);
    $stmt->bindParam(':id', $product_id);

    if ($stmt->execute()) {
        header("Location: manage_products.php");
        exit();
    } else {
        $error_message = "Error updating product.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 10px 0;
            font-weight: bold;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btn-submit {
            display: block;
            width: 150px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .btn-back {
            display: block;
            width: 150px;
            margin: 30px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Product</h2>

    <?php if (isset($error_message)) : ?>
        <div class="error"><?= $error_message; ?></div>
    <?php endif; ?>

    <form action="edit_product.php?id=<?= $product['id']; ?>" method="POST" enctype="multipart/form-data">
        <label for="name">Product Name:</label>
        <input type="text" name="name" id="name" value="<?= htmlspecialchars($product['name']); ?>" required>

        <label for="price">Price:</label>
        <input type="number" name="price" id="price" value="<?= htmlspecialchars($product['price']); ?>" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="4" required><?= htmlspecialchars($product['description']); ?></textarea>

        <label for="stock">Stock:</label>
        <input type="number" name="stock" id="stock" value="<?= htmlspecialchars($product['stock']); ?>" required>

        <label for="category">Category:</label>
        <select name="category" id="category" required>
            <?php foreach ($categories as $category) : ?>
                <option value="<?= $category; ?>" <?= $product['category'] === $category ? 'selected' : ''; ?>>
                    <?= $category; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="sku">SKU:</label>
        <input type="text" name="sku" id="sku" value="<?= htmlspecialchars($product['sku']); ?>" disabled>

        <label for="image">Product Image:</label>
        <input type="file" name="image" id="image">
        <small>Leave empty if you don't want to change the image.</small>

        <button type="submit" class="btn-submit">Save Changes</button>
    </form>

    <a href="manage_products.php" class="btn-back">Back to Products</a>
</div>

</body>
</html>
