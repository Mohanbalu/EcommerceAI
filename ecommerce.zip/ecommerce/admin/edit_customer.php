<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Enhance session security
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

$user_id = $_GET['id']; // Get the user ID from the query string
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id AND role != 'admin'");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch();

if (!$user) {
    header("Location: customer_management.php"); // Redirect to customer management if user not found
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission for updating user information
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $pincode = $_POST['pincode'];
    $location = $_POST['location'];

    $stmt = $conn->prepare("UPDATE users SET full_name = :full_name, email = :email, phone = :phone, address = :address, pincode = :pincode, location = :location WHERE id = :id AND role != 'admin'");
    $stmt->bindParam(':full_name', $full_name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':pincode', $pincode);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':id', $user_id);
    
    if ($stmt->execute()) {
        header("Location: customer_management.php"); // Redirect after successful update
        exit();
    } else {
        $error_message = "Failed to update user information.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
}

.container {
    width: 60%;
    margin: 50px auto;
    background-color: #fff;
    padding: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

h2 {
    text-align: center;
    color: #333;
    font-size: 24px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-size: 16px;
    color: #333;
}

input[type="text"],
input[type="email"] {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
}

button[type="submit"] {
    padding: 12px 20px;
    font-size: 16px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #45a049;
}

a {
    display: inline-block;
    margin-top: 20px;
    text-align: center;
    color: #007BFF;
    text-decoration: none;
    font-size: 16px;
}

a:hover {
    text-decoration: underline;
}

.error {
    color: #e74c3c;
    font-size: 16px;
    text-align: center;
    margin-bottom: 20px;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Customer</h2>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
        <form action="edit_customer.php?id=<?php echo $user['id']; ?>" method="POST">
            <label for="full_name">Full Name:</label>
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

            <label for="phone">Phone:</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>

            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>" required>

            <label for="pincode">Pincode:</label>
            <input type="text" name="pincode" value="<?php echo htmlspecialchars($user['pincode']); ?>" required>

            <label for="location">Location:</label>
            <input type="text" name="location" value="<?php echo htmlspecialchars($user['location']); ?>" required>

            <button type="submit">Update Customer</button>
        </form>
        <a href="customer_management.php">Back to Customer Management</a>
    </div>
</body>
</html>
