<?php
include '../includes/db.php';
session_start();

// Check if the user is an admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Check if an ID is provided in the query string
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Delete product from the database
    try {
        // Prepare and execute the delete query
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);

        // Redirect to manage products page with success message
        header("Location: manage_products.php?msg=Product deleted successfully.");
        exit();
    } catch (PDOException $e) {
        // In case of error, redirect with error message
        header("Location: manage_products.php?msg=Error: Could not delete product.");
        exit();
    }
} else {
    // Redirect if no ID is provided
    header("Location: manage_products.php?msg=Invalid product ID.");
    exit();
}
?>
