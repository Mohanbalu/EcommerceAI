-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2025 at 08:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `basket`
--

CREATE TABLE `basket` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(17, 5, 11, 1, '2025-01-27 05:52:27', '2025-01-27 05:52:27'),
(32, 8, 3, 1, '2025-02-10 18:38:21', '2025-02-10 18:38:21'),
(40, 1, 4, 1, '2025-03-25 11:35:25', '2025-03-25 11:38:37'),
(44, 2, 15, 1, '2025-04-06 06:06:59', '2025-04-06 06:13:54');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('new','read','replied') DEFAULT 'new',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `status`, `replied_at`, `replied_by`) VALUES
(1, 'mohan', 'saradhi@gmail.com', 'good', 'good', '2025-04-06 06:38:31', 'new', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_cost` decimal(10,2) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `payment_method` varchar(255) NOT NULL,
  `payment_details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_cost`, `address`, `phone`, `order_date`, `payment_method`, `payment_details`) VALUES
(1, 1, 14500.00, 'Vijayawada', '8074223801', '2025-01-25 16:09:37', 'cod', 'Cash on Delivery'),
(2, 3, 14649.00, 'Vijayawada', '9988776655', '2025-01-25 17:10:00', 'cod', 'Cash on Delivery'),
(3, 4, 149.00, 'Vijayawada', '9988776655', '2025-01-25 17:30:34', 'cod', 'Cash on Delivery'),
(4, 1, 1600.00, 'Vijayawada', '9988776655', '2025-01-25 21:54:19', 'cod', 'Cash on Delivery'),
(6, 1, 800.00, 'Vijayawada', '9988776655', '2025-01-25 22:12:48', 'cod', 'Cash on Delivery'),
(7, 1, 800.00, 'jaggayyapeta', '9988776644', '2025-01-25 23:42:48', 'cod', 'Cash on Delivery'),
(8, 1, 78908.00, 'vijayawada', '9988776644', '2025-01-25 23:43:29', 'cod', 'Cash on Delivery'),
(9, 1, 149.00, 'vijayawada', '9988776644', '2025-01-25 23:55:10', 'cod', 'Cash on Delivery'),
(10, 1, 149.00, 'vijayawada', '9988776655', '2025-01-25 23:55:21', 'cod', 'Cash on Delivery'),
(11, 1, 149.00, 'vijayawada', '9988776655', '2025-01-26 00:18:43', 'cod', 'Cash on Delivery'),
(12, 1, 399.00, 'vijayawada', '9988776655', '2025-01-26 15:26:22', 'cod', 'Cash on Delivery'),
(13, 1, 121768.00, 'vijayawada', '9988776655', '2025-01-26 15:33:08', 'cod', 'Cash on Delivery'),
(14, 1, 121768.00, 'vijayawada', '9988776655', '2025-01-26 15:34:59', 'cod', 'Cash on Delivery'),
(15, 1, 121768.00, 'vijayawada', '8074223801', '2025-01-26 15:37:37', 'cod', 'Cash on Delivery'),
(16, 5, 121768.00, 'Guntur', '9490851787', '2025-01-27 11:23:26', 'upi', 'kushal@icici'),
(17, 8, 50.00, 'mumbai', '6380599765', '2025-02-02 21:40:12', 'cod', 'Cash on Delivery'),
(18, 1, 121768.00, 'vijayawada', '8074223801', '2025-02-03 11:25:18', 'cod', 'Cash on Delivery'),
(19, 1, 50.00, 'vijayawada', '8074223801', '2025-02-03 11:42:13', 'cod', 'Cash on Delivery'),
(20, 1, 50.00, 'vijayawada', '8074223801', '2025-02-10 11:19:43', 'cod', 'Cash on Delivery'),
(21, 1, 50.00, 'vijayawada', '8074223801', '2025-02-10 11:19:53', 'cod', 'Cash on Delivery'),
(22, 1, 1199.00, 'vijayawada', '8074223801', '2025-02-10 11:23:07', 'cod', 'Cash on Delivery'),
(23, 8, 149.00, 'mumbai', '6380599765', '2025-02-11 00:08:32', 'cod', 'Cash on Delivery'),
(24, 1, 149.00, 'vijayawada', '8074223801', '2025-02-15 10:03:55', 'cod', 'Cash on Delivery'),
(25, 1, 149.00, 'vijayawada', '8074223801', '2025-02-15 10:06:55', 'cod', 'Cash on Delivery'),
(26, 1, 149.00, 'vijayawada', '8074223801', '2025-02-15 11:03:51', 'cod', 'Cash on Delivery'),
(27, 1, 149.00, 'vijayawada', '8074223801', '2025-02-15 11:05:16', 'cod', 'Cash on Delivery'),
(28, 1, 149.00, '[\"Vijayawada\",\"Hyd\"]', '9440804399', '2025-03-10 11:26:29', '', NULL),
(29, 2, 61789.00, 'Jaggayyapeta', '8074223801', '2025-04-06 11:27:43', 'cod', NULL),
(30, 2, 399.00, 'Jaggayyapeta', '8074223801', '2025-04-06 11:36:12', 'cod', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(3, 2, 1, 1),
(4, 3, 3, 1),
(5, 4, 6, 2),
(7, 6, 6, 1),
(8, 7, 6, 1),
(9, 8, 9, 1),
(10, 9, 3, 1),
(11, 10, 3, 1),
(12, 11, 3, 1),
(13, 12, 7, 1),
(14, 13, 11, 1),
(15, 14, 11, 1),
(16, 15, 11, 1),
(17, 16, 11, 1),
(18, 17, 15, 1),
(19, 18, 11, 1),
(20, 19, 15, 1),
(21, 20, 15, 1),
(22, 21, 15, 1),
(23, 22, 4, 1),
(24, 23, 3, 1),
(25, 24, 3, 1),
(26, 25, 3, 1),
(27, 26, 3, 1),
(28, 27, 3, 1),
(29, 28, 3, 1),
(30, 29, 13, 1),
(31, 30, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock` int(11) NOT NULL DEFAULT 0,
  `category` varchar(100) NOT NULL,
  `sku` varchar(100) NOT NULL,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attributes`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`, `created_at`, `stock`, `category`, `sku`, `attributes`) VALUES
(1, 'samsung s23', 14500.00, 'samsung s23 mobile', '../product_images/samsungs23.jpg', '2025-01-25 09:20:54', 5, 'Phones', 'PHO-6794CB247412', NULL),
(3, 'LED Bulb 10W', 149.00, 'Energy-efficient 10W LED bulb, suitable for home and office use.', 'ledbulb.jpg', '2025-01-25 11:35:27', 197, 'Furniture', 'FUR-6794CC7F8323', NULL),
(4, 'Electric Kettle 1.5L', 1199.00, '1.5L electric kettle with auto shut-off feature.', 'kettle.jpg', '2025-01-25 12:28:35', 80, 'Furniture', 'FUR-6794D8F31391', NULL),
(6, 'Web Development', 800.00, 'Web Development Book', 'webdev.jpg', '2025-01-25 12:34:18', 6, 'Books', 'BOO-6794DA4A305', NULL),
(7, 'Python', 399.00, 'Introduction to the python', 'python.png', '2025-01-25 16:52:43', 37, 'Books', 'BOO-679516DB9800', NULL),
(8, 'Bedroom Furniture', 25776.00, 'Melrose Discount Furniture is one of the top discount stores in Los Angeles. We pride ourselves on high-quality selections sold at affordable prices delivered and assembled at your house completely free of charge! We offer various choices in a wide variety of shapes, sizes, and styles so you can find the perfect piece of interior decor to spice up your living room, bedroom, or office! Check out the wide selection from one of the cheap furniture stores in Los Angeles!\r\nInterior design is one of the key factors in creating the best environment in your house to make you feel comfortable and relaxed and it all starts with the type of interior decor items you pick. We work with various high-quality brands to ensure we deliver the best quality furniture to you which will bring value to you and your family.', 'bedroom.jpg', '2025-01-25 17:13:52', 10, 'Furniture', 'FUR-67951BD04226', NULL),
(9, 'MacBook Air M1', 78908.00, 'MacBook Air M1 (33.74 cm / 13&quot;, 256 GB): The effective starting price on cards is ₹78,908 after cashback and discounts.', 'mackbookair13.jpg', '2025-01-25 17:22:54', 2, 'Laptops', 'LAP-67951DEE2530', NULL),
(10, 'HP Pavilion 15', 75000.00, 'HP Pavilion 15-eg2025nr: This laptop features a 12th Generation Intel Core i7-1255U processor, 16 GB of RAM, and a 512 GB SSD. It has a 15.6-inch Full HD display and runs on Windows 11 Pro. It also includes a fingerprint reader, Wi-Fi, Bluetooth, and an HD webcam. This model is known for its sleek design and outstanding performance.', 'hppavilion15.jpeg', '2025-01-25 18:51:04', 21, 'Laptops', 'LAP-679532987409', NULL),
(11, 'Apple iPhone 15 Pro Max', 121768.00, 'Supports MCPTT Quality of Service (FirstNet Rapid Response and FirstNet Push-to-Talk)\r\nForged in titanium – iPhone 15 Pro Max has a strong and light aerospace-grade titanium design with a textured matte-glass back. It also features a Ceramic Shield front that’s tougher than any smartphone glass. And it’s splash, water and dust resistant.¹', 'iphone15pro.png', '2025-01-25 18:54:41', 4, 'Phones', 'PHO-679533717680', NULL),
(12, 'ASUS Vivobook Go 15.6&quot; OLED Laptop', 47329.57, 'ASUS Vivobook Go 15.6&quot; OLED Laptop, AMD Ryzen 5 7520U, 16GB, 512GB, Windows 11 Home, Cool Silver, E1504FA-NS54', 'asusvivobook.jpg', '2025-01-25 18:57:35', 28, 'Laptops', 'LAP-6795341F3076', NULL),
(13, 'Dell XPS 13', 61789.00, 'Dell XPS 13 (9310), 13.4- inch FHD+ Touch Laptop - Intel Core i7-1185G7, 16GB 4267MHz LPDDR4x RAM, 512GB SSD, Iris Xe Graphics, Windows 10 Pro - Platinum Silver with Black Palmrest', 'delllaptopxps13.jpg', '2025-01-25 19:47:08', 44, 'Laptops', 'LAP-67953FBC6282', '{\"specialization\":\"XPS 13\",\"processor\":\"i7\",\"ram\":\"16 GB\",\"rom\":\"\"}'),
(15, 'orbit', 50.00, 'Why this gum? Smell like a gem always! Wrigleys Orbit Spearmint Sugarfree Chewing Gum gives you the confidence needed to rise to the occasion and seize the moment with an assured cashback worth Rs.25. You can always count on Orbit gum for a clean and fresh mouth feel at any time. What makes it different? This sugar free chewing gum gives you clean and healthy teeth and lets you focus on yourself, while its smooth and refreshing cool spearmint flavour gives you the readiness to make the most of your moment and emerge out stronger than who you were. Now be fresh breath ready with Orbit, even with the mask on! When to have this gum? Pop a gum while working out in a gym, while studying for better concentration or to freshen up behind the mask.\r\n\r\nStorage Instructions: Store in a cool and dry condition.', 'orbit.jpg', '2025-01-28 05:10:11', 501, 'Food and Beverage', 'FOO-67A05D523044', '[]'),
(16, 'OnePlus Nord Buds 2r True Wireless', 1799.00, 'OnePlus Nord Buds 2r True Wireless in Ear Earbuds with Mic, 12.4mm Drivers, Playback:Upto 38hr case,4-Mic Design, IP55 Rating [Deep Grey]\r\n', 'OnePlus Nord Buds 2r True Wireless.jpg', '2025-04-06 04:04:09', 34, 'Accessories', 'ACC-67F1FD392110', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `stock_movements`
--

CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `change_amount` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `change_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('user','admin') DEFAULT 'user',
  `full_name` varchar(100) NOT NULL,
  `pincode` varchar(6) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `wallet_balance` decimal(10,2) DEFAULT 0.00,
  `address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '[]' CHECK (json_valid(`address`)),
  `phone` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '[]' CHECK (json_valid(`phone`)),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `role`, `full_name`, `pincode`, `location`, `profile_picture`, `wallet_balance`, `address`, `phone`, `reset_token`, `reset_expiry`) VALUES
(1, '', 'mohanbalu292@gmail.com', '$2y$10$8JyXPvFtxAQscl2lsIAbE.lAH6XhtKCat1TZ/cSokm1ymrUyI6W7G', '2025-01-25 09:35:02', 'user', 'Mohan balu', '521175', 'jaggayyapeta', '../uploads/profilemine.png', 0.00, '[\"Vijayawada\",\"Hyd\"]', '[\"8074223801\",\"8074223812\"]', '640a44587bb4cd9d47fefbda46b31f78440b7673b44a4066e10787bc7b116f93', '2025-04-05 12:15:04'),
(2, '', 'saradhi@gmail.com', '$2y$10$hz/gIPaLYnbbOEAE8cw0A.8yLWl71EV4M1bE4ZMFYPF2JfSYR/EIy', '2025-01-25 10:19:08', 'user', 'saradhi', '521175', 'Jaggayyapeta', '../uploads/Offer-Letter-prodigy.png', 0.00, '[\"jaggayyapeta\"]', '[\"8074223801\"]', NULL, NULL),
(3, '', 'arjun@gmail.com', '$2y$10$fxhUevsHFCLGUXvmeDzZaO1sSyE.yGnqqNqWN6MivOOHcicDV2B6G', '2025-01-25 11:38:43', 'user', 'allu arjun', '527175', 'Hyderbad', '../uploads/alluarjun.jpg', 0.00, '[]', '[]', NULL, NULL),
(4, '', 'admin@gmail.com', '$2y$10$WP0fWhua7XBtP5WDTq/JG.EgeXz/pqoVccrjVQCq7T1Mm05bXDiQC', '2025-01-25 11:43:27', 'admin', 'admin', '521175', 'Hyderbad', '../uploads/admin.jpg', 0.00, '[]', '[]', NULL, NULL),
(5, '', 'kushal@gmail.com', '$2y$10$vtwSygNCXM9g0Yf38C.U1OGJfdD3N75kczWcyb47/oUW27PbglC/G', '2025-01-27 05:51:31', 'user', 'kushal jasti', '522504', 'Guntur', '../uploads/kushal.png', 0.00, '[]', '[]', NULL, NULL),
(6, '', 'hari@gmail.com', '$2y$10$WmXjsRSQHM/oFF7AZFXWuumWUPBHblKFr3v61N412V4VvSjUXbnUe', '2025-01-27 15:35:58', 'user', 'sri hari', '522345', 'ongole', NULL, 0.00, '[]', '[]', NULL, NULL),
(7, '', 'rachapudiamulya2022@gmail.com', '$2y$10$nyMB1bKHtjrjwE4iWD6.0.ttl.RcSqQvKFkUQWNyU/unpk/D/5ZDa', '2025-01-27 15:54:46', 'user', 'amulya', '522035', 'Guntur', '../uploads/amulya.png', 0.00, '[]', '[]', NULL, NULL),
(8, '', 'himavanth@gmail.com', '$2y$10$0D7/jQ848M41RjfHwHUYAesz2Gma2E8byMMHha2MYOR1DghlaODSi', '2025-02-02 15:57:17', 'user', 'Himavanth', '522303', 'Mumbai', '../uploads/himawanth.jpg', 0.00, '[]', '[]', NULL, NULL),
(9, 'srinag', 'pvenkatasrinag@gmail.com', '$2y$10$Q5VepmK1.CucBIBtw19dL.bMuyJWZxSjXwfVwJwjNZG0e1Sf.xcve', '2025-03-07 07:10:40', 'user', 'srinag', '522236', 'Guntur', 'uploads/3.jpg', 0.00, '\"Guntur\"', '9440804399', NULL, NULL),
(10, 'sukesh', 'sukesh@gmail.com', '$2y$10$NTu6nn6N7nEl18cHkL//veQqrmzAgj9SDRAE5mvuH0oZI6R16Jepq', '2025-04-05 09:11:58', 'user', 'sukesh', '522303', 'ongole', 'uploads/object-detection-input.jpg', 0.00, '\"Ongole, Andhra Pradesh\"', '78965412237', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wallet`
--

CREATE TABLE `wallet` (
  `user_id` int(11) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallet`
--

INSERT INTO `wallet` (`user_id`, `balance`) VALUES
(1, 300.00),
(2, 10.00);

-- --------------------------------------------------------

--
-- Table structure for table `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallet_transactions`
--

INSERT INTO `wallet_transactions` (`id`, `user_id`, `type`, `amount`, `description`, `transaction_date`) VALUES
(1, 1, 'top-up', 100.00, 'Manual top-up', '2025-03-10 06:03:48'),
(2, 1, 'top-up', 100.00, 'Manual top-up', '2025-03-10 06:04:43'),
(3, 1, 'top-up', 100.00, 'Manual top-up', '2025-03-10 06:04:56'),
(4, 2, 'top-up', 10.00, 'Manual top-up', '2025-04-06 06:28:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `replied_by` (`replied_by`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `products` ADD FULLTEXT KEY `name` (`name`,`description`);

--
-- Indexes for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wallet`
--
ALTER TABLE `wallet`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `basket`
--
ALTER TABLE `basket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stock_movements`
--
ALTER TABLE `stock_movements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `basket`
--
ALTER TABLE `basket`
  ADD CONSTRAINT `basket_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `basket_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD CONSTRAINT `contact_messages_ibfk_1` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
