<?php
session_start();
require_once 'includes/db.php';

if (!isset($_GET['id'])) {
    // Handle case where product ID is not set in the query string
    echo "Product not found!";
    exit();
}

$product_id = $_GET['id'];

// Fetch the product details from the database
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    // If the product doesn't exist, display an error message
    echo "Product not found!";
    exit();
}

// Decode the JSON attributes if they exist
$attributes = json_decode($product['attributes'], true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']); ?> - Product Details</title>
    <style>
/* General styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

header {
    background-color: #333;
    color: white;
    padding: 15px;
    text-align: center;
    position: sticky;
    top: 0;
    z-index: 1000;
}

header h1 {
    font-size: 36px;
}

header nav {
    margin-top: 10px;
}

header nav .nav-link,
header nav .cart-link {
    color: white;
    text-decoration: none;
    padding: 10px;
    margin-right: 20px;
    font-size: 18px;
}

header nav .cart-icon {
    width: 20px;
    vertical-align: middle;
}

header nav .user-info {
    display: inline-block;
    margin-left: 20px;
    text-align: center;
}

header nav .profile-image {
    width: 30px;
    border-radius: 50%;
    margin-bottom: 5px;
}

header nav .username {
    color: white;
    font-size: 16px;
}

header nav .logout-button {
    background-color: #f44336;
    color: white;
    border: none;
    padding: 8px 15px;
    cursor: pointer;
    margin-top: 10px;
}

header nav .logout-button:hover {
    background-color: #d32f2f;
}

.main-container {
    padding: 20px;
}

.product-details {
    background-color: white;
    border-radius: 8px;
    padding: 30px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    max-width: 1200px;
    margin: 0 auto;
}

.product-details h2 {
    font-size: 30px;
    color: #333;
    margin-bottom: 20px;
}

.product-info {
    display: flex;
    justify-content: space-between;
    gap: 30px;
}

.product-image img {
    max-width: 100%;
    max-height: 300px;
    border-radius: 8px;
}

.product-description {
    flex: 1;
}

.product-description p {
    font-size: 18px;
    color: #555;
    line-height: 1.6;
}

.product-description h3 {
    font-size: 22px;
    color: #444;
    margin-top: 20px;
}

.product-description ul {
    list-style-type: none;
    padding: 0;
}

.product-description ul li {
    font-size: 18px;
    color: #555;
    margin-bottom: 10px;
}

.product-description strong {
    color: #333;
}

.add-to-cart-button {
    background-color: #007BFF;
    color: white;
    font-size: 18px;
    padding: 12px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-align: center;
    margin-top: 20px;
    transition: background-color 0.3s ease;
}

.add-to-cart-button:hover {
    background-color: #0056b3;
}

footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 10px;
    margin-top: 40px;
}

footer p {
    margin: 0;
    font-size: 14px;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .product-info {
        flex-direction: column;
        align-items: center;
    }

    .product-image img {
        max-width: 80%;
        margin-bottom: 20px;
    }

    .product-description {
        text-align: center;
    }

    .product-details {
        padding: 20px;
    }
}

    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1>Product Details</h1>
        </div>
        <nav>
        <a href="index.php" class="nav-link">Home</a>
            <a href="pages/cart.php" class="cart-link">
                <img src="images/cart.jpg" alt="Cart" class="cart-icon">
                Cart
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="user-info">
                    <img src="<?= htmlspecialchars(file_exists('uploads/' . $_SESSION['profile_picture']) ? 'uploads/' . $_SESSION['profile_picture'] : 'uploads/default-profile.png'); ?>" 
     alt="<?= htmlspecialchars($_SESSION['name']); ?>" class="profile-image">
                    <span class="username"><?= htmlspecialchars($_SESSION['name']); ?></span>
                </div>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="logout" class="logout-button">Logout</button>
                </form>
            <?php endif; ?>
        </nav>
    </header>

    <div class="main-container">
        <main>
            <div class="product-details">
                <h2><?= htmlspecialchars($product['name']); ?></h2>
                <div class="product-info">
                    <div class="product-image">
                        <?php if (!empty($product['image'])): ?>
                            <img src="product_images/<?= htmlspecialchars($product['image']); ?>" alt="<?= htmlspecialchars($product['name']); ?>">
                        <?php endif; ?>
                    </div>
                    
                    <div class="product-description">
                        <p><strong>Product ID:</strong> <?= htmlspecialchars($product['id']); ?></p>
                        <p><strong>Price:</strong> $<?= number_format($product['price'], 2); ?></p>
                        <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($product['description'])); ?></p>
                        <p><strong>Category:</strong> <?= htmlspecialchars($product['category']); ?></p>
                        <p><strong>Stock:</strong> <?= htmlspecialchars($product['stock']); ?> units available</p>
                        <p><strong>SKU:</strong> <?= htmlspecialchars($product['sku']); ?></p>
                        <p><strong>Created At:</strong> <?= date('F d, Y', strtotime($product['created_at'])); ?></p>

                        <!-- Displaying attributes if they exist -->
                        <?php if (!empty($attributes)): ?>
                            <h3>Attributes:</h3>
                            <ul>
                                <?php foreach ($attributes as $key => $value): ?>
                                    <li><strong><?= htmlspecialchars($key); ?>:</strong> <?= htmlspecialchars($value); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>

                        <!-- Add to cart button -->
                        <form method="POST" action="pages/cart.php">
                            <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
                            <button type="submit" name="add_to_cart" class="add-to-cart-button">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <footer>
        <p>&copy; <?= date('Y'); ?> Online Store. All rights reserved.</p>
    </footer>
</body>
</html>
