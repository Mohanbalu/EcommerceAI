<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['name'])) {
    $stmt = $conn->prepare("SELECT full_name, profile_picture FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $_SESSION['name'] = $user['full_name'] ?? 'User';
    $_SESSION['profile_picture'] = $user['profile_picture'] ?? 'images/default-profile.png';
}

// Logout functionality
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

$filters = [];
if (!empty($_GET['category'])) {
    $filters[] = "category = :category";
}
if (!empty($_GET['price_range'])) {
    $filters[] = "price <= :price";
}

$query = "SELECT * FROM products";
if ($filters) {
    $query .= " WHERE " . implode(' AND ', $filters);
}
$query .= " ORDER BY category, price";

$stmt = $conn->prepare($query);

if (!empty($_GET['category'])) {
    $stmt->bindValue(':category', $_GET['category']);
}
if (!empty($_GET['price_range'])) {
    $stmt->bindValue(':price', $_GET['price_range']);
}

$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$products_by_category = [];
foreach ($products as $product) {
    $products_by_category[$product['category']][] = $product;
}

$category_price_stmt = $conn->query("
    SELECT 
        category, 
        MIN(price) AS min_price, 
        MAX(price) AS max_price, 
        AVG(price) AS avg_price
    FROM products 
    GROUP BY category
");
$categories_with_prices = $category_price_stmt->fetchAll(PDO::FETCH_ASSOC);

$category_price_ranges = [];
foreach ($categories_with_prices as $row) {
    $category_price_ranges[$row['category']] = [
        'min' => $row['min_price'],
        'max' => $row['max_price'],
        'average' => $row['avg_price']
    ];
}
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ?");
$stmt->execute(["%$search%", "%$search%"]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
$filters = [];
$params = [];
if (!empty($_GET['category'])) {
    $filters[] = "category = :category";
    $params[':category'] = $_GET['category'];
}
if (!empty($_GET['price_range'])) {
    $filters[] = "price <= :price";
    $params[':price'] = $_GET['price_range'];
}
if (!empty($_GET['search'])) {
    $filters[] = "name LIKE :search OR category LIKE :search";
    $params[':search'] = "%" . $_GET['search'] . "%";
}
$query = "SELECT * FROM products";
if ($filters) {
    $query .= " WHERE " . implode(' AND ', $filters);
}
$query .= " ORDER BY category, price";

$stmt = $conn->prepare($query);

if (!empty($_GET['category'])) {
    $stmt->bindValue(':category', $_GET['category']);
}
if (!empty($_GET['price_range'])) {
    $stmt->bindValue(':price', $_GET['price_range']);
}
if (!empty($search)) {
    $stmt->bindValue(':search', $search);
}

$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
$filters = [];
if (!empty($_GET['category'])) {
    $filters[] = "category = :category";
}

if (!empty($_GET['price_range'])) {
    $filters[] = "price <= :price";
}

// Check if search term is provided
if (!empty($_GET['search'])) {
    $filters[] = "name LIKE :search";
}

$query = "SELECT * FROM products";
if ($filters) {
    $query .= " WHERE " . implode(' AND ', $filters);
}
$query .= " ORDER BY category, price";

$stmt = $conn->prepare($query);

if (!empty($_GET['category'])) {
    $stmt->bindValue(':category', $_GET['category']);
}

if (!empty($_GET['price_range'])) {
    $stmt->bindValue(':price', $_GET['price_range']);
}

if (!empty($_GET['search'])) {
    $search_term = "%" . $_GET['search'] . "%";  // Adding wildcards for partial matches
    $stmt->bindValue(':search', $search_term);
}

$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (isset($_POST['add_to_cart'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];
    
    // Check if the product is in stock
    $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if ($product['stock'] > 0) {
        // Check if the product is already in the user's cart
        $stmt = $conn->prepare("SELECT * FROM basket WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $existing_item = $stmt->fetch();

        if ($existing_item) {
            // If the product is already in the cart, increase quantity
            $stmt = $conn->prepare("UPDATE basket SET quantity = quantity + 1 WHERE id = ?");
            $stmt->execute([$existing_item['id']]);
        } else {
            // If the product is not in the cart, insert a new item
            $stmt = $conn->prepare("INSERT INTO basket (user_id, product_id, quantity) VALUES (?, ?, 1)");
            $stmt->execute([$user_id, $product_id]);
        }
        
        // Reduce stock by 1
        $stmt = $conn->prepare("UPDATE products SET stock = stock - 1 WHERE id = ?");
        $stmt->execute([$product_id]);

        echo "Product added to cart!";
    } else {
        echo "Sorry, this product is out of stock.";
    }
}

if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    
    // Check if product is in stock
    $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if ($product['stock'] > 0) {
        // Logic to add to cart
        $user_id = $_SESSION['user_id'];

        // Check if the product is already in the cart
        $stmt = $conn->prepare("SELECT * FROM basket WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        $existing_item = $stmt->fetch();

        if ($existing_item) {
            // Update cart quantity
            $stmt = $conn->prepare("UPDATE basket SET quantity = quantity + 1 WHERE id = ?");
            $stmt->execute([$existing_item['id']]);
        } else {
            // Add new item to cart
            $stmt = $conn->prepare("INSERT INTO basket (user_id, product_id, quantity) VALUES (?, ?, 1)");
            $stmt->execute([$user_id, $product_id]);
        }

        // Reduce stock by 1
        $stmt = $conn->prepare("UPDATE products SET stock = stock - 1 WHERE id = ?");
        $stmt->execute([$product_id]);

        echo "Product added to cart!";
    } else {
        echo "Sorry, this product is out of stock.";
    }
} else {
    // Handle case where product_id is not set
    echo "Product ID is missing.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        a{
            text-decoration: none;
        }
        body {
    background-color: #f9f9f9;
    color: #333;
    margin: 0;
    font-family: Arial, sans-serif;
    transition: background-color 0.3s, color 0.3s;
}

body.dark-mode {
    background-color: #121212;
    color: #e0e0e0;
}
header {
    background-color: #333;
    color: white;
    padding: 20px 0;
}
header.dark-mode {
    background-color: #222;
}
.header-container {
    width: 80%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

h1 {
    font-size: 2rem;
    margin: 0;
}

nav {
    display: flex;
    align-items: center;
}
.category-section {
    margin-bottom: 30px; /* Adds spacing between categories */
}

.category-section h3 {
    margin-bottom: 10px;
    font-size: 1.5rem;
    font-weight: bold;
}
.cart-link {
    display: inline-flex;
    align-items: center;
    text-decoration: none;
    color: white;
    font-weight: bold;
    margin-right: 20px;
}

.cart-icon {
    width: 25px;
    margin-right: 10px;
}

.user-info {
    display: inline-flex;
    align-items: center;
    margin-left: 15px;
}

.profile-image {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
    border: 1px solid #ccc;
}

.username {
    font-size: 1em;
    font-weight: bold;
    color: #fff;
}

.logout-button {
    background-color: #f44336;
    color: white; /* White text */
    border: none; /* Remove default border */
    padding: 10px 20px; /* Increase padding */
    cursor: pointer; /* Pointer on hover */
    font-size: 14px; /* Font size */
    font-weight: bold; /* Bold text */
    border-radius: 25px; /* Full rounded corners */
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.logout-button.dark-mode {
    background-color: #b71c1c;
}
.logout-button:hover {
    background-color: #d32f2f; /* Slightly darker red on hover */
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    transform: scale(1.05); /* Slightly enlarge on hover */
}


.main-container {
    padding: 40px 20px;
}

main h2 {
    font-size: 2rem;
    text-align: center;
    color: #333;
    margin-bottom: 30px;
}
.product-list {
    padding: 20px;
}
.product {
    border: 1px solid #ccc; /* Optional: add border for each product */
    border-radius: 5px;
    padding: 10px;
    text-align: center;
    width: 150px; /* Sets width for each product card */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Optional: adds a subtle shadow */
}
.products{
    flex: 3;
}
.content-with-filters {
    display: flex;
    justify-content: space-between;
    gap: 20px; /* Space between products and filters */
}
.product h3 {
    margin: 0;
    margin-bottom: 10px;
    font-size: 1.2rem;
    color: #333;
}
.product h4 {
    margin: 10px 0;
    font-size: 1rem;
}
.product-container {
    display: flex; /* Ensures products are arranged horizontally */
    flex-wrap: wrap; /* Allows products to wrap to the next row if space is limited */
    gap: 20px; /* Adds spacing between products */
}
.product p {
    margin: 5px 0;
    font-size: 0.9rem;
    color: #555;
}
.product img {
    max-width: 100%;
    max-height: 100px;
    object-fit: contain;
    margin-bottom: 10px;
}
.product:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.product-list .product {
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
hr {
    border: none;
    border-top: 1px solid #ddd;
    margin: 20px 0;
}
.product .product-image {
    max-width: 150px; /* Image width */
    height: auto; /* Maintain aspect ratio */
    margin-bottom: 15px;
    border-radius: 5px;
}

.add-to-cart-button {
    margin-top: 5px;
    padding: 5px 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

.add-to-cart-button:hover {
    background-color: #0056b3;
}

footer {
    background-color: #333;
    color: white;
    padding: 15px;
    text-align: center;
    font-size: 0.9rem;
}
@media (max-width: 768px) {
    .product-list {
        grid-template-columns: repeat(2, 1fr); /* Two columns for smaller screens */
    }
}

@media (max-width: 480px) {
    .product-list {
        grid-template-columns: 1fr; /* One column for very small screens */
    }
}.filters {
    flex: 1; /* Occupy a smaller portion of the width for filters */
    max-width: 300px; /* Optional: Limit the filter width */
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    height: fit-content; /* Adjust to fit content dynamically */
    align-self: flex-start; /* Align filters to the start */
}
.filters h2 {
    margin-bottom: 15px;
    font-size: 1.5rem;
}
.filters label {
    display: block;
    font-weight: bold;
    margin-top: 10px;
}
.filters select, .filters input[type="range"] {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
}
@media (max-width: 768px) {
    .filters {
        position: relative;
        top: auto;
        left: auto;
        max-width: none;
        display: flex; /* Row-style layout for filters */
        flex-direction: row;
        justify-content: space-evenly;
        padding: 5px;
    }
}

.filters button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    margin-top: 10px;
    border-radius: 4px;
    cursor: pointer;
}

.filters button:hover {
    background-color: #0056b3;
}
.product-display {
    margin-left: 320px; /* Space for the sidebar filters */
    padding: 20px;
}

@media (max-width: 768px) {
    .product-display {
        margin-left: 0; /* No fixed sidebar for smaller screens */
    }
}
.nav-link {
    color: white;
    font-weight: bold;
    text-decoration: none;
    margin-right: 20px; /* Spacing between links */
}

.nav-link:hover {
    text-decoration: underline; /* Optional hover effect */
}
/* Add this CSS to your existing style section */
.chatbot {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 250px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    padding: 10px;
    display: none;
    flex-direction: column;
}

.chatbot-header {
    display: flex;
    justify-content: space-between;
    font-weight: bold;
}

.chatbot-messages {
    max-height: 200px;
    overflow-y: auto;
    margin: 10px 0;
    flex-grow: 1;
}

#user-message {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.chatbot button {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
}.search-box {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .search-box input {
            width: 300px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .search-box button {
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-box button:hover {
            background-color: #218838;
        } </style>
</head>
<body>
<header>
<form action="search.php" method="get" class="search-box">
    <input type="text" id="search" name="search" placeholder="Search for products..." autocomplete="off">
    <button type="submit">Search</button>
    <div id="search-results" class="search-dropdown"></div>
</form>

    <div class="header-container">
        <h1>Welcome to Our Store</h1>
        <nav>
        <a href="index.php" class="nav-link">Home</a>
            <a href="pages/cart.php" class="cart-link">
                <img src="images/cart.jpg" alt="Cart" class="cart-icon">
                Cart
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="./pages/profile.php" class="profile-link" style="text-decoration: none;">
    <div class="user-info">
        <img 
            src="<?= htmlspecialchars(file_exists('uploads/' . $_SESSION['profile_picture']) ? 'uploads/' . $_SESSION['profile_picture'] : 'uploads/default-profile.png'); ?>" 
            alt="<?= htmlspecialchars($_SESSION['name']); ?>" class="profile-image">
        <span class="username"><?= htmlspecialchars($_SESSION['name']); ?></span>
    </div>
</a>
<form action="logout.php" method="POST" style="display: inline;">
    <button type="submit" name="logout" class="logout-button">Logout</button>
</form>

            <?php endif; ?>
            <button id="theme-toggle" class="theme-toggle" onclick="bgchange()">🌙</button>
        </nav>
    </div>
</header>

<div class="main-container">
    <main>
        <div class="content-with-filters">
            <section class="products">
                <h2>Products</h2>
                <div class="product-list">
                    <?php if (empty($products)) : ?>
                        <p>No products available.</p>
                    <?php else : ?>
                        <?php foreach ($products_by_category as $category => $products_in_category) : ?>
                            <div class="category-section">
                                <h3><?= htmlspecialchars($category); ?></h3>
                                <div class="product-container">
                                    <?php foreach ($products_in_category as $product) : ?>
                                        <div class="product">
    <h4>
        <a href="product_detail.php?id=<?= $product['id']; ?>"><?= htmlspecialchars($product['name']); ?></a>
    </h4>
    <p>Price: <?= number_format($product['price'], 2); ?></p>
    <?php if (!empty($product['image'])) : ?>
        <img src="product_images/<?= htmlspecialchars($product['image']); ?>" alt="<?= htmlspecialchars($product['name']); ?>" class="product-image">
    <?php endif; ?>

    <!-- Check stock availability -->
    <?php if ($product['stock'] > 0) : ?>
        <form method="POST" action="pages/cart.php">
    <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
    <button type="submit" name="add_to_cart" class="add-to-cart-button">Add to Cart</button>
</form>

    <?php else : ?>
        <p class="out-of-stock-message" style="color: red; font-weight: bold;">Stock Not Available</p>
    <?php endif; ?>
</div>

                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
<aside class="filters">
    <h2>Filters</h2>
    <form method="GET" id="filters-form">
        <!-- Category Dropdown -->
        <label for="category">Category:</label>
        <select name="category" id="category" onchange="document.getElementById('filters-form').submit()">
            <option value="">All Categories</option>
            <?php foreach ($category_price_ranges as $category => $prices) : ?>
                <option value="<?= htmlspecialchars($category); ?>" <?= ($_GET['category'] ?? '') === $category ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($category); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php if (!empty($_GET['category']) && isset($category_price_ranges[$_GET['category']])) :
            $range = $category_price_ranges[$_GET['category']];
        ?>
            <label for="price_range">Price Range:</label>
            <input type="range" id="price_range" name="price_range" 
                   min="<?= $range['min']; ?>" 
                   max="<?= $range['max']; ?>" 
                   value="<?= $range['average']; ?>" 
                   oninput="document.getElementById('range-value').innerText = this.value;">
            <span id="range-value"><?= $range['average']; ?></span>
        <?php endif; ?>
        
        <button type="submit" style="margin-top: 10px;">Apply</button>
    </form>
</aside>

        </div>
    </main>
</div>
<!-- Add this to your existing HTML -->
<div id="chatbot" class="chatbot">
    <div class="chatbot-header">
        <span>Chat with us!</span>
        <button id="close-chat" onclick="toggleChat()">X</button>
    </div>
    <div class="chatbot-messages" id="chat-messages">
        <p class="bot-message">Hello! How can I assist you today? (Type "order <product_name>" to place an order.)</p>
    </div>
    <input type="text" id="user-message" placeholder="Type a message..." onkeyup="sendMessage(event)">
</div>
<footer>
    <p>&copy; <?= date('Y'); ?> Online Store. All rights reserved.</p>
</footer>
</body>
<script>
function bgchange() {
    const body = document.body;
    const themeToggle = document.getElementById("theme-toggle");

    body.classList.toggle("dark-mode");

    // Update the button's icon
    const isDarkMode = body.classList.contains("dark-mode");
    themeToggle.textContent = isDarkMode ? "☀️" : "🌙";

    // Save the state in localStorage
    localStorage.setItem("theme", isDarkMode ? "dark" : "light");
}

// Apply saved theme preference on page load
document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
        document.getElementById("theme-toggle").textContent = "☀️";
    }
});
</script>
<script>
document.getElementById("search").addEventListener("keyup", function () {
    let searchQuery = this.value.trim();

    if (searchQuery.length > 0) {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "search_suggestions.php?query=" + encodeURIComponent(searchQuery), true);

        xhr.onload = function () {
            if (this.status === 200) {
                document.getElementById("search-results").innerHTML = this.responseText;
                document.getElementById("search-results").style.display = "block";
            }
        };

        xhr.send();
    } else {
        document.getElementById("search-results").style.display = "none";
    }
});

document.addEventListener("click", function (e) {
    if (!document.querySelector(".search-box").contains(e.target)) {
        document.getElementById("search-results").style.display = "none";
    }
});
</script>

<!-- CSS for Dropdown -->
<style>
.search-dropdown {
    position: absolute;
    background: white;
    border: 1px solid #ccc;
    width: 100%;
    max-width: 300px;
    display: none;
    z-index: 1000;
}

.search-dropdown a {
    display: block;
    padding: 10px;
    text-decoration: none;
    color: black;
}

.search-dropdown a:hover {
    background: #f0f0f0;
}
</style>
</html>