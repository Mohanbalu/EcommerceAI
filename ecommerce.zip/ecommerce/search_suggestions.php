<?php
require_once 'includes/db.php'; // Database connection

if (isset($_GET['query'])) {
    $query = trim($_GET['query']);

    // Define stop words (common words to ignore in search)
    $stopWords = ['i', 'want', 'a', 'the', 'this', 'that', 'is', 'how', 'much', 'does', 'cost', 'do', 'you', 'have', 'show', 'me', 'under'];

    // Convert query to lowercase and split into words
    $words = explode(' ', strtolower($query));

    // Remove stop words
    $keywords = array_diff($words, $stopWords);

    if (empty($keywords)) {
        echo '<p>Please enter a valid search query.</p>';
        exit();
    }

    // Identify category if mentioned in the query
    $category = null;
    $categories = ["electronics", "fashion", "books", "toys", "home", "beauty"]; // Modify based on your actual categories

    foreach ($keywords as $word) {
        if (in_array($word, $categories)) {
            $category = $word;
            $keywords = array_diff($keywords, [$word]); // Remove category from keywords
            break;
        }
    }

    // Identify price filter (e.g., "under 500")
    $priceLimit = null;
    foreach ($keywords as $key => $word) {
        if (is_numeric($word)) {
            $priceLimit = (float)$word;
            unset($keywords[$key]);
            break;
        }
    }

    // Create search pattern
    $searchPattern = "%" . implode('%', $keywords) . "%";

    // Construct SQL query
    $sql = "SELECT id, name, price, category FROM products WHERE name LIKE ?";

    // Add category filter if available
    $params = [$searchPattern];
    if ($category) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }

    // Add price filter if available
    if ($priceLimit) {
        $sql .= " AND price <= ?";
        $params[] = $priceLimit;
    }

    $sql .= " LIMIT 5";

    // Execute query
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Display results
    if ($results) {
        echo '<ul class="search-results">';
        foreach ($results as $row) {
            echo '<li><a href="product_detail.php?id=' . htmlspecialchars($row['id']) . '">' . 
                htmlspecialchars($row['name']) . ' (' . htmlspecialchars($row['category']) . ') - ₹' . 
                number_format($row['price'], 2) . 
                '</a></li>';
        }
        echo '</ul>';
    } else {
        echo '<p>No products found</p>';
    }
}
?>
