<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Get current wallet balance
$stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id = ?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);
$current_balance = $wallet ? $wallet['balance'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = floatval($_POST['amount']);

    if ($amount <= 0) {
        $error_message = "Please enter a valid amount.";
    } else {
        try {
            $conn->beginTransaction();

            // Check if wallet exists
            if ($wallet) {
                // Update balance
                $stmt = $conn->prepare("UPDATE wallet SET balance = balance + ? WHERE user_id = ?");
                $stmt->execute([$amount, $user_id]);
            } else {
                // Create wallet
                $stmt = $conn->prepare("INSERT INTO wallet (user_id, balance) VALUES (?, ?)");
                $stmt->execute([$user_id, $amount]);
            }

            // Insert transaction
            $stmt = $conn->prepare("INSERT INTO wallet_transactions (user_id, type, amount, description) VALUES (?, 'top-up', ?, 'Manual top-up')");
            $stmt->execute([$user_id, $amount]);

            $conn->commit();
            $success_message = "Top-up successful! \$" . number_format($amount, 2) . " added.";
            
            // Update current balance after successful top-up
            $current_balance += $amount;
        } catch (PDOException $e) {
            $conn->rollBack();
            $error_message = "Top-up failed: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Top-Up Wallet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --success-color: #059669;
            --error-color: #dc2626;
            --border-color: #e5e7eb;
            --text-color: #1f2937;
            --text-secondary: #6b7280;
            --background-color: #f3f4f6;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: var(--background-color);
            color: var(--text-color);
            line-height: 1.5;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .topup-container {
            width: 100%;
            max-width: 440px;
            background: white;
            padding: 2rem;
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 2rem;
        }

        h2 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .balance-display {
            background: var(--background-color);
            padding: 1rem;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .balance-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
        }

        .balance-amount {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }

        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .quick-amount {
            background: none;
            border: 1px solid var(--border-color);
            padding: 0.75rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.875rem;
            font-weight: 500;
            transition: all 0.2s;
        }

        .quick-amount:hover {
            background: var(--background-color);
            border-color: var(--primary-color);
            color: var(--primary-color);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        input[type="number"] {
            width: 100%;
            padding: 0.75rem;
            font-size: 1rem;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            transition: border-color 0.2s;
        }

        input[type="number"]:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        button {
            width: 100%;
            padding: 0.875rem;
            background-color: var(--primary-color);
            border: none;
            color: white;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background-color: var(--primary-hover);
        }

        .message {
            margin: 1rem 0;
            padding: 1rem;
            border-radius: 8px;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .success { 
            background: #dcfce7; 
            color: var(--success-color);
        }

        .error { 
            background: #fee2e2; 
            color: var(--error-color);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            margin-top: 1.5rem;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.875rem;
            transition: color 0.2s;
        }

        .back-link:hover {
            color: var(--primary-color);
        }

        .back-link svg {
            margin-right: 0.5rem;
            width: 16px;
            height: 16px;
        }

        @media (max-width: 480px) {
            .topup-container {
                padding: 1.5rem;
            }

            .quick-amounts {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="topup-container">
        <div class="header">
            <h2>Top-Up Your Wallet</h2>
        </div>

        <div class="balance-display">
            <div class="balance-label">Current Balance</div>
            <div class="balance-amount">$<?= number_format($current_balance, 2) ?></div>
        </div>

        <?php if ($success_message): ?>
            <div class="message success"><?= $success_message ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="message error"><?= $error_message ?></div>
        <?php endif; ?>

        <form method="POST" action="" id="topupForm">
            <div class="quick-amounts">
                <button type="button" class="quick-amount" data-amount="10">$10</button>
                <button type="button" class="quick-amount" data-amount="25">$25</button>
                <button type="button" class="quick-amount" data-amount="50">$50</button>
                <button type="button" class="quick-amount" data-amount="100">$100</button>
                <button type="button" class="quick-amount" data-amount="200">$200</button>
                <button type="button" class="quick-amount" data-amount="500">$500</button>
            </div>

            <div class="form-group">
                <label for="amount">Custom Amount ($)</label>
                <input type="number" name="amount" id="amount" step="0.01" min="1" required 
                       placeholder="Enter amount">
            </div>

            <button type="submit">Top-Up Now</button>
        </form>

        <a href="wallet.php" class="back-link">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to My Wallet
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const amountInput = document.getElementById('amount');
            const quickAmounts = document.querySelectorAll('.quick-amount');
            
            quickAmounts.forEach(button => {
                button.addEventListener('click', function() {
                    const amount = this.dataset.amount;
                    amountInput.value = amount;
                });
            });

            // Format amount input to 2 decimal places on blur
            amountInput.addEventListener('blur', function() {
                if (this.value) {
                    this.value = parseFloat(this.value).toFixed(2);
                }
            });
        });
    </script>
</body>
</html>