<?php
session_start();
include '../includes/db.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: pages/login.php");
    exit();
}

// Fetch user data from the database
$stmt = $conn->prepare("SELECT full_name, email, profile_picture FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Update user profile
if (isset($_POST['update_profile'])) {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];

    // Handle profile picture upload
    $new_profile_picture = $user['profile_picture'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
            $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
        }
    }

    // Update database with new details (no password change)
    $update_sql = "UPDATE users SET full_name = ?, email = ?, profile_picture = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->execute([$new_name, $new_email, $new_profile_picture]);

    // Update session data
    $_SESSION['name'] = $new_name;
    $_SESSION['profile_picture'] = $new_profile_picture;
    header("Location: profile.php");
    exit();
}

// Get basket item count
$stmt = $conn->prepare("SELECT COUNT(*) FROM basket WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$basket_count = $stmt->fetchColumn();

// Get wallet balance
$stmt = $conn->prepare("SELECT wallet_balance FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$wallet_balance = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #333;
    color: #fff;
    padding: 20px;
}

.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

h1 {
    margin: 0;
}

nav a {
    color: #fff;
    text-decoration: none;
    margin: 0 10px;
}

nav a:hover {
    text-decoration: underline;
}

.user-info {
    display: flex;
    align-items: center;
}

.profile-image {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.username {
    font-weight: bold;
}

.main-container {
    width: 60%;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

form {
    display: grid;
    gap: 15px;
}

label {
    font-weight: bold;
    font-size: 14px;
}

input[type="text"],
input[type="email"],
input[type="password"],
input[type="file"] {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    width: 100%;
    font-size: 16px;
}

input[type="file"] {
    padding: 5px;
}

button[type="submit"] {
    padding: 12px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #45a049;
}

footer {
    background-color: #333;
    color: #fff;
    padding: 10px;
    text-align: center;
}

footer p {
    margin: 0;
}

@media (max-width: 768px) {
    .main-container {
        width: 80%;
    }

    .header-container {
        flex-direction: column;
        text-align: center;
    }

    .user-info {
        margin-top: 10px;
    }
}
/* Dropdown styles */
.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-toggle {
    text-decoration: none;
    color: #fff;
    padding: 10px 20px;
    background-color: #333;
    border-radius: 5px;
    cursor: pointer;
}

.dropdown-toggle:hover {
    background-color: #444;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #333;
    min-width: 160px;
    z-index: 1;
    border-radius: 5px;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {
    background-color: #575757;
}

.dropdown:hover .dropdown-content {
    display: block;
}

.nav-link {
    color: #fff;
    text-decoration: none;
    margin: 0 10px;
}

.nav-link:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>
<header>
    <div class="header-container">
        <h1>Welcome to Our Store</h1>
        <nav>
            <a href="index.php" class="nav-link">Home</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="dropdown">
    <a href="#" class="nav-link dropdown-toggle">My Account</a>
    <div class="dropdown-content">
        <a href="editprofile.php">Edit Profile</a>
        <a href="my_orders.php">My Orders</a>
        <a href="pages/my_account.php">Account Settings</a>
        <a href="pages/cart.php">My Basket (<?= $basket_count ?? 0; ?> items)</a>
        <a href="pages/smart_basket.php">My Smart Basket</a>
        <a href="pages/wallet.php">My Wallet (₹<?= $wallet_balance ?? 0; ?>)</a>
        <a href="pages/contact_us.php">Contact Us</a>
        <form method="POST" style="display: inline;">
    <button type="submit" name="logout" class="logout-button" href = "../index.php">Logout</button>
</form>

    </div>
</div>
            <?php else: ?>
                <a href="pages/login.php" class="nav-link">Login</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<div class="main-container">
    <main>
        <h2>Your Profile</h2>
        <div class="user-info">
        <img src="../uploads/<?= htmlspecialchars(file_exists('../uploads/' . $_SESSION['profile_picture']) ? $_SESSION['profile_picture'] : 'default-profile.png'); ?>" 
        alt="<?= htmlspecialchars($_SESSION['name']); ?>" class="profile-image">
            <div>
                <p><strong>Full Name:</strong> <?= htmlspecialchars($user['full_name']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            </div>
        </div>
    </main>
</div>
<footer>
    <p>&copy; <?= date('Y'); ?> Online Store. All rights reserved.</p>
</footer>

</body>
</html>
