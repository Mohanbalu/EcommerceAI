<?php
session_start();
include '../includes/db.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: pages/login.php");
    exit();
}

// Fetch user data from the database
$stmt = $conn->prepare("SELECT full_name, email, profile_picture FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Update user profile
if (isset($_POST['update_profile'])) {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];

    // Handle profile picture upload
    $new_profile_picture = $user['profile_picture'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
            $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
        }
    }

    // Update database with new details
    $update_sql = "UPDATE users SET full_name = ?, email = ?, profile_picture = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->execute([$new_name, $new_email, $new_profile_picture]);

    // Update session data
    $_SESSION['name'] = $new_name;
    $_SESSION['profile_picture'] = $new_profile_picture;
    header("Location: profile.php");
    exit();
}

// Get basket item count
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT COUNT(*) FROM basket WHERE user_id = ?");
$stmt->execute([$user_id]);
$basket_count = $stmt->fetchColumn();

// Get wallet balance
$stmt = $conn->prepare("SELECT wallet_balance FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$wallet_balance = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --secondary-color: #6B7280;
            --success-color: #10B981;
            --danger-color: #EF4444;
            --background-color: #F3F4F6;
            --card-background: #FFFFFF;
            --text-primary: #111827;
            --text-secondary: #6B7280;
            --border-color: #E5E7EB;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background-color);
            color: var(--text-primary);
            line-height: 1.5;
        }

        .header {
            background-color: var(--card-background);
            padding: 1.25rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .nav-link {
            color: var(--text-primary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: var(--background-color);
            color: var(--primary-color);
        }

        .dropdown {
            position: relative;
        }

        .dropdown-toggle {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .dropdown-toggle:hover {
            background-color: var(--background-color);
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background-color: var(--card-background);
            min-width: 200px;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            padding: 0.5rem;
            z-index: 1000;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 0.25rem;
            transition: all 0.2s ease;
        }

        .dropdown-link:hover {
            background-color: var(--background-color);
            color: var(--primary-color);
        }

        .main-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .profile-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
        }

        .profile-sidebar {
            background-color: var(--card-background);
            padding: 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 1.5rem;
            display: block;
            border: 4px solid var(--primary-color);
        }

        .profile-name {
            font-size: 1.25rem;
            font-weight: 600;
            text-align: center;
            margin-bottom: 0.5rem;
        }

        .profile-email {
            color: var(--text-secondary);
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            padding: 1rem 0;
            border-top: 1px solid var(--border-color);
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .profile-content {
            background-color: var(--card-background);
            padding: 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--border-color);
        }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .action-card {
            background-color: var(--background-color);
            padding: 1.5rem;
            border-radius: 0.5rem;
            text-align: center;
            transition: all 0.2s ease;
        }

        .action-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .action-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .action-title {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        .action-description {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .logout-button {
            background-color: var(--danger-color);
            color: white;
            border: none;
            padding: 0.75rem 1rem;
            border-radius: 0.375rem;
            font-weight: 500;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.2s ease;
        }

        .logout-button:hover {
            background-color: #DC2626;
        }

        @media (max-width: 768px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }

            .header-container {
                flex-direction: column;
                gap: 1rem;
            }

            .nav-menu {
                flex-direction: column;
                width: 100%;
            }

            .dropdown-content {
                width: 100%;
                position: static;
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <a href="../index.php" class="logo">Our Store</a>
            <nav class="nav-menu">
                <a href="../index.php" class="nav-link">Home</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="dropdown">
                        <div class="dropdown-toggle">
                            <img src="../uploads/<?= htmlspecialchars(file_exists('../uploads/' . $_SESSION['profile_picture']) ? $_SESSION['profile_picture'] : 'default-profile.png'); ?>" 
                                alt="Profile" 
                                style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover;">
                            <span><?= htmlspecialchars($_SESSION['name']); ?></span>
                        </div>
                        <div class="dropdown-content">
                            <a href="editprofile.php" class="dropdown-link">
                                <span>📝</span> Edit Profile
                            </a>
                            <a href="my_orders.php" class="dropdown-link">
                                <span>📦</span> My Orders
                            </a>
                            <a href="mybasket.php" class="dropdown-link">
                                <span>🛒</span> My Basket (<?= $basket_count ?? 0; ?>)
                            </a>
                            <a href="smart_basket.php" class="dropdown-link">
                                <span>🔄</span> Smart Basket
                            </a>
                            <a href="wallet.php" class="dropdown-link">
                                <span>💰</span> Wallet (₹<?= number_format($wallet_balance ?? 0, 2); ?>)
                            </a>
                            <a href="pages/contact_us.php" class="dropdown-link">
                                <span>📞</span> Contact Us
                            </a>
                            <form method="POST" style="margin-top: 0.5rem;">
                                <button type="submit" name="logout" class="logout-button">Logout</button>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="nav-link">Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="main-container">
        <div class="profile-grid">
            <aside class="profile-sidebar">
                <img src="../uploads/<?= htmlspecialchars(file_exists('../uploads/' . $user['profile_picture']) ? $user['profile_picture'] : 'default-profile.png'); ?>" 
                     alt="<?= htmlspecialchars($user['full_name']); ?>" 
                     class="profile-picture">
                <h2 class="profile-name"><?= htmlspecialchars($user['full_name']); ?></h2>
                <p class="profile-email"><?= htmlspecialchars($user['email']); ?></p>
                
                <div class="profile-stats">
                    <div class="stat-item">
                        <div class="stat-value"><?= $basket_count ?? 0; ?></div>
                        <div class="stat-label">Items in Basket</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">₹<?= number_format($wallet_balance ?? 0, 2); ?></div>
                        <div class="stat-label">Wallet Balance</div>
                    </div>
                </div>
            </aside>

            <main class="profile-content">
                <h2 class="section-title">Quick Actions</h2>
                <div class="quick-actions">
                    <a href="editprofile.php" class="action-card">
                        <div class="action-icon">📝</div>
                        <h3 class="action-title">Edit Profile</h3>
                        <p class="action-description">Update your personal information</p>
                    </a>
                    <a href="my_orders.php" class="action-card">
                        <div class="action-icon">📦</div>
                        <h3 class="action-title">My Orders</h3>
                        <p class="action-description">Track your orders and history</p>
                    </a>
                    <a href="mybasket.php" class="action-card">
                        <div class="action-icon">🛒</div>
                        <h3 class="action-title">My Basket</h3>
                        <p class="action-description">View and manage your items</p>
                    </a>
                    <a href="wallet.php" class="action-card">
                        <div class="action-icon">💰</div>
                        <h3 class="action-title">My Wallet</h3>
                        <p class="action-description">Manage your wallet balance</p>
                    </a>
                </div>
            </main>
        </div>
    </div>
</body>
</html>