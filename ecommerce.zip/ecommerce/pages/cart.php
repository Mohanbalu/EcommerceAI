<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id']; // Assuming user ID is stored in session
$error_message = '';
$success_message = '';

// Handle Clear Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_cart'])) {
    try {
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $success_message = "Your cart has been cleared.";
    } catch (PDOException $e) {
        $error_message = "An error occurred while clearing the cart: " . htmlspecialchars($e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Handle Add to Cart
        if (isset($_POST['add_to_cart'])) {
            $product_id = (int)$_POST['product_id'];
            $quantity = isset($_POST['quantity']) ? max(1, (int)$_POST['quantity']) : 1;
        
            // Check product stock
            $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if (!$product) {
                $error_message = "Product not found.";
            } elseif ($product['stock'] <= 0) {
                $error_message = "This product is out of stock.";
            } elseif ($quantity > $product['stock']) {
                $error_message = "Requested quantity exceeds available stock.";
            } else {
                // Proceed with adding to cart
                $stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
                $stmt->execute([$user_id, $product_id]);
                $cart_item = $stmt->fetch(PDO::FETCH_ASSOC);
        
                if ($cart_item) {
                    $new_quantity = $cart_item['quantity'] + $quantity;
                    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
                    $stmt->execute([$new_quantity, $user_id, $product_id]);
                } else {
                    $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
                    $stmt->execute([$user_id, $product_id, $quantity]);
                }
                $success_message = "Product added to cart successfully.";
            }
        }

        // Handle Quantity Update
        if (isset($_POST['update_quantity'])) {
            $product_id = (int)$_POST['product_id'];
            $quantity = max(1, (int)$_POST['quantity']); // Minimum quantity is 1
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$quantity, $user_id, $product_id]);
            $success_message = "Cart updated successfully.";
        }

        // Handle Product Removal
        if (isset($_POST['remove_from_cart'])) {
            $product_id = (int)$_POST['product_id'];
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$user_id, $product_id]);
            $success_message = "Product removed from cart.";
        }

        // Handle Payment via Wallet
        if (isset($_POST['pay_with_wallet'])) {
            $total_cost = array_reduce($cart_items, function ($carry, $item) {
                return $carry + ($item['price'] * $item['quantity']);
            }, 0);

            // Fetch user wallet balance
            $stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($wallet && $wallet['balance'] >= $total_cost) {
                // Deduct from wallet balance
                $new_balance = $wallet['balance'] - $total_cost;
                $stmt = $conn->prepare("UPDATE wallet SET balance = ? WHERE user_id = ?");
                $stmt->execute([$new_balance, $user_id]);

                // Insert transaction record
                $stmt = $conn->prepare("INSERT INTO wallet_transactions (user_id, type, amount, description) 
                                        VALUES (?, 'payment', ?, 'Payment for cart items')");
                $stmt->execute([$user_id, $total_cost]);

                // Clear the cart after successful payment
                $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
                $stmt->execute([$user_id]);

                $success_message = "Payment successful! Your cart has been cleared.";
            } else {
                $error_message = "Insufficient balance in your wallet.";
            }
        }
    } catch (PDOException $e) {
        $error_message = "An error occurred: " . htmlspecialchars($e->getMessage());
    }
}

// Fetch the user's cart items with product details
try {
    $stmt = $conn->prepare("
        SELECT 
            p.id AS product_id, p.name, p.image, p.price, c.quantity 
        FROM 
            cart c 
        JOIN 
            products p 
        ON 
            c.product_id = p.id 
        WHERE 
            c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cart_items = [];
    $error_message = "Failed to load cart items: " . htmlspecialchars($e->getMessage());
}

$total_cost = array_reduce($cart_items, function ($carry, $item) {
    return $carry + ($item['price'] * $item['quantity']);
}, 0);
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Shopping Cart</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3B82F6;
            --primary-dark: #2563EB;
            --secondary-color: #6366F1;
            --danger-color: #DC2626;
            --success-color: #059669;
            --background-color: #F3F4F6;
            --text-color: #111827;
            --text-light: #6B7280;
            --border-color: #E5E7EB;
            --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --header-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            padding-top: var(--header-height);
        }

        header {
            background-color: white;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: var(--header-height);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
            height: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logo i {
            font-size: 1.75rem;
        }

        nav {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .nav-link {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-link i {
            font-size: 1.25rem;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1.5rem;
        }

        .cart-section {
            background-color: white;
            border-radius: 1rem;
            box-shadow: var(--card-shadow);
            padding: 2rem;
        }

        .section-title {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            font-size: 2rem;
            color: var(--primary-color);
        }

        .cart-item {
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 2rem;
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            align-items: center;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .cart-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .item-image {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 0.75rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .item-details {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .item-name {
            font-weight: 600;
            font-size: 1.25rem;
            color: var(--text-color);
        }

        .item-price {
            font-size: 1.125rem;
            color: var(--primary-color);
            font-weight: 600;
        }

        .item-subtotal {
            color: var(--text-light);
            font-size: 0.875rem;
        }

        .item-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .quantity-input {
            width: 100px;
            padding: 0.75rem;
            border: 2px solid var(--border-color);
            border-radius: 0.5rem;
            text-align: center;
            font-size: 1rem;
            font-weight: 500;
            transition: border-color 0.2s;
        }

        .quantity-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .btn {
            padding: 0.75rem 1.25rem;
            border-radius: 0.5rem;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }

        .btn i {
            font-size: 1.25rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-1px);
        }

        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }

        .btn-danger:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        .cart-summary {
            margin-top: 2rem;
            padding: 2rem;
            background-color: #F8FAFC;
            border-radius: 0.75rem;
        }

        .total-cost {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary-color);
            text-align: right;
            margin-bottom: 1.5rem;
        }

        .cart-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .cart-actions-right {
            display: flex;
            gap: 1rem;
        }

        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
        }

        .empty-cart i {
            font-size: 4rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }

        .empty-cart p {
            color: var(--text-light);
            font-size: 1.25rem;
            margin-bottom: 2rem;
        }

        .message {
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .message i {
            font-size: 1.5rem;
        }

        .error-message {
            background-color: #FEE2E2;
            color: var(--danger-color);
        }

        .success-message {
            background-color: #D1FAE5;
            color: var(--success-color);
        }

        .out-of-stock {
            color: var(--danger-color);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .cart-item {
                grid-template-columns: 1fr;
                text-align: center;
                gap: 1.5rem;
                padding: 2rem 1.5rem;
            }

            .item-image {
                margin: 0 auto;
            }

            .item-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .cart-actions {
                flex-direction: column;
                gap: 1.5rem;
            }

            .cart-actions-right {
                flex-direction: column;
                width: 100%;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">
                <i class='bx bxs-store'></i>
                ShopCart
            </a>
            <nav>
                <a href="../index.php" class="nav-link">
                    <i class='bx bxs-home'></i>
                    Home
                </a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="user-info">
                        <img src="../uploads/<?= htmlspecialchars(file_exists('../uploads/' . $_SESSION['profile_picture']) ? $_SESSION['profile_picture'] : 'default-profile.png'); ?>" 
                             alt="<?= htmlspecialchars($_SESSION['name']); ?>" class="profile-image">
                        <span class="username"><?= htmlspecialchars($_SESSION['name']); ?></span>
                    </div>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="container">
        <div class="cart-section">
            <h2 class="section-title">
                <i class='bx bxs-cart'></i>
                Your Shopping Cart
            </h2>
            
            <?php if ($error_message): ?>
                <div class="message error-message">
                    <i class='bx bxs-error'></i>
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success_message): ?>
                <div class="message success-message">
                    <i class='bx bxs-check-circle'></i>
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <?php if (empty($cart_items)): ?>
                <div class="empty-cart">
                    <i class='bx bxs-cart'></i>
                    <p>Your cart is empty</p>
                    <a href="../index.php" class="btn btn-primary">
                        <i class='bx bxs-shopping-bag'></i>
                        Continue Shopping
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item">
                        <img src="../product_images/<?= htmlspecialchars($item['image']) ?>" 
                             alt="<?= htmlspecialchars($item['name']) ?>" 
                             class="item-image">
                        
                        <div class="item-details">
                            <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                            <div class="item-price">$<?= number_format($item['price'], 2) ?></div>
                            <div class="item-subtotal">Subtotal: $<?= number_format($item['price'] * $item['quantity'], 2) ?></div>
                        </div>

                        <div class="item-actions">
                            <?php
                            $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
                            $stmt->execute([$item['product_id']]);
                            $product_stock = $stmt->fetch(PDO::FETCH_ASSOC)['stock'];
                            ?>
                            
                            <?php if ($product_stock > 0): ?>
                                <form method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <input type="number" 
                                           name="quantity" 
                                           value="<?= $item['quantity'] ?>" 
                                           class="quantity-input" 
                                           min="1" 
                                           max="<?= $product_stock ?>" 
                                           required>
                                    <button type="submit" name="update_quantity" class="btn btn-primary">
                                        <i class='bx bxs-refresh'></i>
                                        Update
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="out-of-stock">
                                    <i class='bx bxs-x-circle'></i>
                                    Out of Stock
                                </span>
                            <?php endif; ?>

                            <form method="POST">
                                <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                <button type="submit" name="remove_from_cart" class="btn btn-danger">
                                    <i class='bx bxs-trash'></i>
                                    Remove
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="cart-summary">
                    <div class="total-cost">
                        Total: $<?= number_format($total_cost, 2) ?>
                    </div>

                    <?php
                    $cart_out_of_stock = false;
                    foreach ($cart_items as $item) {
                        $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
                        $stmt->execute([$item['product_id']]);
                        $product_stock = $stmt->fetch(PDO::FETCH_ASSOC)['stock'];
                        if ($product_stock <= 0) {
                            $cart_out_of_stock = true;
                            break;
                        }
                    }
                    ?>

                    <div class="cart-actions">
                        <form method="POST">
                            <button type="submit" name="clear_cart" class="btn btn-danger">
                                <i class='bx bxs-x-circle'></i>
                                Clear Cart
                            </button>
                        </form>
                        
                        <div class="cart-actions-right">
                            <a href="../index.php" class="btn btn-primary">
                                <i class='bx bxs-shopping-bag'></i>
                                Continue Shopping
                            </a>
                            <a href="payment.php" 
                               class="btn btn-primary"
                               <?= $cart_out_of_stock ? 'style="opacity: 0.5; pointer-events: none;"' : '' ?>>
                                <i class='bx bxs-credit-card'></i>
                                Proceed to Checkout
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>