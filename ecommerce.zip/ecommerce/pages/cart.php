<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id']; // Assuming user ID is stored in session
$error_message = '';
$success_message = '';

// Handle Add to Cart with Quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add_to_cart'])) {
            $product_id = (int)$_POST['product_id'];
            $quantity = isset($_POST['quantity']) ? max(1, (int)$_POST['quantity']) : 1;
        
            // Check product stock
            $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if (!$product) {
                $error_message = "Product not found.";
            } elseif ($product['stock'] <= 0) {
                $error_message = "This product is out of stock.";
            } elseif ($quantity > $product['stock']) {
                $error_message = "Requested quantity exceeds available stock.";
            } else {
                // Proceed with adding to cart
                $stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
                $stmt->execute([$user_id, $product_id]);
                $cart_item = $stmt->fetch(PDO::FETCH_ASSOC);
        
                if ($cart_item) {
                    $new_quantity = $cart_item['quantity'] + $quantity;
                    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
                    $stmt->execute([$new_quantity, $user_id, $product_id]);
                } else {
                    $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
                    $stmt->execute([$user_id, $product_id, $quantity]);
                }
                $success_message = "Product added to cart successfully.";
            }
        }
        

        // Handle Quantity Update
        if (isset($_POST['update_quantity'])) {
            $product_id = (int)$_POST['product_id'];
            $quantity = max(1, (int)$_POST['quantity']); // Minimum quantity is 1
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$quantity, $user_id, $product_id]);
            $success_message = "Cart updated successfully.";
        }

        // Handle Product Removal
        if (isset($_POST['remove_from_cart'])) {
            $product_id = (int)$_POST['product_id'];
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$user_id, $product_id]);
            $success_message = "Product removed from cart.";
        }
    } catch (PDOException $e) {
        $error_message = "An error occurred: " . htmlspecialchars($e->getMessage());
    }
}

// Fetch the user's cart items with product details
try {
    $stmt = $conn->prepare("
        SELECT 
            p.id AS product_id, p.name, p.image, p.price, c.quantity 
        FROM 
            cart c 
        JOIN 
            products p 
        ON 
            c.product_id = p.id 
        WHERE 
            c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cart_items = [];
    $error_message = "Failed to load cart items: " . htmlspecialchars($e->getMessage());
}

$total_cost = array_reduce($cart_items, function ($carry, $item) {
    return $carry + ($item['price'] * $item['quantity']);
}, 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .cart-item img {
            max-width: 100px;
            border-radius: 8px;
            margin-right: 20px;
        }
        .item-details {
            flex-grow: 1;
        }
        .item-name {
            font-size: 1.2em;
            font-weight: bold;
            color: #343a40;
        }
        .item-price {
            font-size: 1.1em;
            color: #495057;
        }
        .item-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }
        .item-actions button, .item-actions form button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            margin-left: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .item-actions button:hover, .item-actions form button:hover {
            background-color: #0056b3;
        }
        .quantity {
            width: 60px;
            padding: 5px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .cart-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .cart-actions a {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 1.1em;
            transition: background-color 0.3s;
        }
        .cart-actions a:hover {
            background-color: #218838;
        }
        .total-cost {
            font-size: 1.6em;
            font-weight: bold;
            color: #343a40;
            text-align: center;
            margin-top: 20px;
        }
        .empty-cart {
            text-align: center;
            font-size: 1.2em;
            color: #6c757d;
        }/* Basic styling */
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    color: #333;
}

/* Header and Navigation Bar */
header {
    background-color: #007bff;
    color: white;
    padding: 15px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

h1 {
    margin-left: 20px;
    font-size: 1.8em;
    font-weight: bold;
}

/* Navigation Links */
nav {
    display: flex;
    align-items: center;
    margin-right: 20px;
}

.nav-link {
    color: white;
    text-decoration: none;
    margin: 0 15px;
    font-size: 1.2em;
    transition: color 0.3s ease;
}

.nav-link:hover {
    color: #f8f9fa;
}

/* Cart Icon */
.cart-link {
    color: white;
    display: flex;
    align-items: center;
    text-decoration: none;
}

.cart-link:hover {
    color: #f8f9fa;
}

.cart-icon {
    width: 25px;
    margin-right: 5px;
}

.cart-link {
    font-size: 1.1em;
}

/* User Profile Section */
.user-info {
    display: flex;
    align-items: center;
    margin-right: 20px;
}

.profile-image {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.username {
    font-size: 1.1em;
    color: white;
}

/* Logout Button */
.logout-button {
    background-color: #dc3545;
    color: white;
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.1em;
    margin-left: 15px;
    transition: background-color 0.3s ease;
}

.logout-button:hover {
    background-color: #c82333;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    header {
        flex-direction: column;
        text-align: center;
    }

    h1 {
        margin-bottom: 10px;
    }

    nav {
        flex-direction: column;
        margin-top: 10px;
    }

    .nav-link {
        margin: 8px 0;
    }

    .user-info {
        margin-top: 10px;
    }

    .cart-link {
        font-size: 1.2em;
    }

    .logout-button {
        font-size: 1.1em;
        padding: 10px 14px;
    }
}
    </style>
</head>
<body>
<div class="container">
    <header>
        <div class="header-container">
            <h1>Product Details</h1>
        </div>
        <nav>
            <a href="../index.php" class="nav-link">Home</a>
            <a href="pages/cart.php" class="cart-link">
                <img src="../images/cart.jpg" alt="Cart" class="cart-icon">
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="user-info">
                    <img src="../uploads/<?= htmlspecialchars(file_exists('../uploads/' . $_SESSION['profile_picture']) ? $_SESSION['profile_picture'] : 'default-profile.png'); ?>" 
                         alt="<?= htmlspecialchars($_SESSION['name']); ?>" class="profile-image">
                    <span class="username"><?= htmlspecialchars($_SESSION['name']); ?></span>
                </div>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="logout" class="logout-button">Logout</button>
                </form>
            <?php endif; ?>
        </nav>
    </header>

    <h2>Available Products</h2>
    <?php
if (!isset($products) || !is_array($products)) {
    $products = []; // Set it to an empty array if not already set
}
?>

<div class="product-list">
    <?php foreach ($products as $product): ?>
        <div class="product">
            <img src="product_images/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
            <h3><?= htmlspecialchars($product['name']) ?></h3>
            <p>Price: <?= number_format($product['price'], 2) ?></p>
            <p>Stock: <?= $product['stock'] > 0 ? $product['stock'] : 'Out of stock' ?></p>
            
            <?php if ($product['stock'] > 0): ?>
                <form method="POST">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                    <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock'] ?>" required>
                    <button type="submit" name="add_to_cart">Add to Cart</button>
                </form>
            <?php else: ?>
                <button class="out-of-stock" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

    <h2>Your Cart</h2>
    <?php if ($error_message): ?>
        <div class="error-message"><?= htmlspecialchars($error_message) ?></div>
    <?php elseif ($success_message): ?>
        <div class="success-message"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>
    
    <?php if (empty($cart_items)): ?>
        <p class="empty-cart">Your cart is empty.</p>
    <?php else: ?>
        <?php foreach ($cart_items as $item): ?>
    <div class="cart-item">
        <img src="../product_images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="item-image">
        <div class="item-details">
            <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
            <div class="item-price"><?= htmlspecialchars(number_format($item['price'], 2)) ?> x <?= $item['quantity'] ?></div>
        </div>
        <div class="item-actions">
            <?php
            // Check the stock status of the product
            $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
            $stmt->execute([$item['product_id']]);
            $product_stock = $stmt->fetch(PDO::FETCH_ASSOC)['stock'];
            ?>
            
            <?php if ($product_stock > 0): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" class="quantity" min="1" required>
                    <button type="submit" name="update_quantity">Update Quantity</button>
                </form>
            <?php else: ?>
                <button class="out-of-stock" disabled>Out of Stock</button>
            <?php endif; ?>

            <form method="POST" style="display:inline;">
                <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                <button type="submit" name="remove_from_cart">Remove</button>
            </form>
        </div>
    </div>
<?php endforeach; ?>

        <div class="total-cost">
            Total: <?= number_format($total_cost, 2); ?>
        </div>
        <?php
$cart_out_of_stock = false;
foreach ($cart_items as $item) {
    $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$item['product_id']]);
    $product_stock = $stmt->fetch(PDO::FETCH_ASSOC)['stock'];

    if ($product_stock <= 0) {
        $cart_out_of_stock = true;
        break; // No need to check further if one product is already out of stock
    }
}
?>

<div class="cart-actions">
    <a href="../index.php">Back to Shop</a>
    <a href="payment.php" <?= $cart_out_of_stock ? 'class="disabled" style="pointer-events:none;"' : '' ?>>Proceed to Checkout</a>
</div>

    <?php endif; ?>
</div>
</body>

</html>