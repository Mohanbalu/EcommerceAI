<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id'];

$error_message = '';
$success_message = '';

// Fetch wallet balance
try {
    $stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
    $balance = $wallet ? $wallet['balance'] : 0.00;
} catch (PDOException $e) {
    $error_message = "Unable to load wallet: " . htmlspecialchars($e->getMessage());
    $balance = 0.00;
}

// Fetch transactions
try {
    $stmt = $conn->prepare("SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY transaction_date DESC");
    $stmt->execute([$user_id]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $transactions = [];
    $error_message .= "<br>Unable to load transactions: " . htmlspecialchars($e->getMessage());
}

$basket_count = $_SESSION['basket_count'] ?? 0;
$wallet_balance = $_SESSION['wallet_balance'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wallet</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --primary-hover: #4338CA;
            --success-color: #059669;
            --danger-color: #DC2626;
            --warning-color: #D97706;
            --border-color: #E5E7EB;
            --text-primary: #111827;
            --text-secondary: #6B7280;
            --bg-primary: #F9FAFB;
            --bg-white: #FFFFFF;
            --green-light: #ECFDF5;
            --red-light: #FEF2F2;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.5;
            color: var(--text-primary);
            background-color: var(--bg-primary);
        }

        header {
            background-color: var(--bg-white);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        nav {
            display: flex;
            gap: 1rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: var(--bg-primary);
            color: var(--primary-color);
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .wallet-card {
            background-color: var(--bg-white);
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .wallet-balance {
            font-size: 3rem;
            font-weight: 600;
            color: var(--success-color);
            margin: 1rem 0;
        }

        .balance-label {
            color: var(--text-secondary);
            font-size: 1.125rem;
            margin-bottom: 2rem;
        }

        .add-money-btn {
            display: inline-flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: background-color 0.2s ease;
        }

        .add-money-btn:hover {
            background-color: var(--primary-hover);
        }

        .transactions-section {
            background-color: var(--bg-white);
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
        }

        .transaction-list {
            display: grid;
            gap: 1rem;
        }

        .transaction-item {
            display: grid;
            grid-template-columns: 1fr auto auto;
            align-items: center;
            padding: 1rem;
            border-radius: 0.5rem;
            background-color: var(--bg-primary);
            transition: transform 0.2s ease;
        }

        .transaction-item:hover {
            transform: translateY(-2px);
        }

        .transaction-info {
            display: flex;
            flex-direction: column;
        }

        .transaction-type {
            font-weight: 500;
            color: var(--text-primary);
            text-transform: capitalize;
        }

        .transaction-date {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .transaction-amount {
            font-weight: 600;
            padding: 0.25rem 0.75rem;
            border-radius: 0.375rem;
        }

        .amount-credit {
            color: var(--success-color);
            background-color: var(--green-light);
        }

        .amount-debit {
            color: var(--danger-color);
            background-color: var(--red-light);
        }

        .transaction-description {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }

        .message {
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
        }

        .error {
            background-color: var(--red-light);
            color: var(--danger-color);
            border: 1px solid #FCA5A5;
        }

        .success {
            background-color: var(--green-light);
            color: var(--success-color);
            border: 1px solid #6EE7B7;
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: var(--text-secondary);
        }

        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 1rem;
            }

            nav {
                flex-wrap: wrap;
                justify-content: center;
            }

            .wallet-balance {
                font-size: 2.5rem;
            }

            .transaction-item {
                grid-template-columns: 1fr;
                gap: 0.5rem;
                text-align: center;
            }

            .transaction-info {
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="page-title">My Wallet</h1>
            <nav>
                <a href="../index.php" class="nav-link">Home</a>
                <a href="my_orders.php" class="nav-link">My Orders</a>
                <a href="cart.php" class="nav-link">Cart (<?= htmlspecialchars($basket_count) ?>)</a>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php if ($error_message): ?>
            <div class="message error"><?= $error_message ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="message success"><?= $success_message ?></div>
        <?php endif; ?>

        <div class="wallet-card">
            <div class="balance-label">Available Balance</div>
            <div class="wallet-balance">₹<?= number_format($balance, 2) ?></div>
            <a href="topup.php" class="add-money-btn">Add Money to Wallet</a>
        </div>

        <div class="transactions-section">
            <h2 class="section-title">Transaction History</h2>
            <?php if (empty($transactions)): ?>
                <div class="empty-state">
                    <p>No transactions found in your wallet.</p>
                </div>
            <?php else: ?>
                <div class="transaction-list">
                    <?php foreach ($transactions as $tx): 
                        $isCredit = in_array($tx['type'], ['top-up', 'refund']);
                    ?>
                        <div class="transaction-item">
                            <div class="transaction-info">
                                <span class="transaction-type"><?= ucfirst(htmlspecialchars($tx['type'])) ?></span>
                                <span class="transaction-description"><?= htmlspecialchars($tx['description']) ?></span>
                            </div>
                            <span class="transaction-date">
                                <?= date('d M Y, h:i A', strtotime($tx['transaction_date'])) ?>
                            </span>
                            <span class="transaction-amount <?= $isCredit ? 'amount-credit' : 'amount-debit' ?>">
                                <?= $isCredit ? '+' : '-' ?>₹<?= number_format($tx['amount'], 2) ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>