<?php
session_start();

$error_message = '';
$success_message = '';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id'];

// Fetch cart items
try {
    $stmt = $conn->prepare("
        SELECT 
            p.id AS product_id, p.name, p.image, p.price, c.quantity 
        FROM 
            cart c 
        JOIN 
            products p ON c.product_id = p.id 
        WHERE 
            c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cart_items = [];
    $error_message = "Error loading basket: " . htmlspecialchars($e->getMessage());
}

$total_cost = array_reduce($cart_items, function ($carry, $item) {
    return $carry + ($item['price'] * $item['quantity']);
}, 0);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Smart Basket</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .message {
            padding: 12px;
            border-radius: 6px;
            margin: 15px 0;
        }
        .success {
            background-color: #e0f8e0;
            color: #2f8f2f;
        }
        .error {
            background-color: #f8e0e0;
            color: #a94442;
        }
        .basket-item {
            display: flex;
            gap: 20px;
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            align-items: center;
        }
        .basket-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }
        .item-details {
            flex: 1;
        }
        .item-actions {
            display: flex;
            gap: 10px;
        }
        input[type="number"] {
            width: 60px;
            padding: 5px;
        }
        button {
            padding: 8px 12px;
            border: none;
            background: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
        button.remove {
            background-color: #dc3545;
        }
        button:hover {
            opacity: 0.9;
        }
        .total {
            text-align: right;
            font-size: 1.2em;
            font-weight: bold;
        }
        .basket-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        .basket-actions form {
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Smart Basket</h1>

        <?php if ($error_message): ?>
            <div class="message error"><?= $error_message ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="message success"><?= $success_message ?></div>
        <?php endif; ?>

        <?php if (empty($cart_items)): ?>
            <p style="text-align:center;">Your basket is empty.</p>
        <?php else: ?>
            <?php foreach ($cart_items as $item): ?>
                <div class="basket-item">
                    <img src="../product_images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                    <div class="item-details">
                        <h3><?= htmlspecialchars($item['name']) ?></h3>
                        <p>Price: $<?= number_format($item['price'], 2) ?></p>
                        <p>Quantity: <?= $item['quantity'] ?></p>
                        <p>Subtotal: $<?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                    </div>
                    <div class="item-actions">
                        <form method="post" action="cart.php">
                            <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                            <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" required>
                            <button type="submit" name="update_quantity">Update</button>
                        </form>
                        <form method="post" action="cart.php">
                            <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                            <button class="remove" type="submit" name="remove_from_cart">Remove</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="total">
                Total: $<?= number_format($total_cost, 2) ?>
            </div>

            <div class="basket-actions">
                <form method="post" action="cart.php">
                    <button type="submit" name="clear_cart">Clear Cart</button>
                </form>
                <form action="checkout.php" method="post">
                    <button type="submit">Proceed to Checkout</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
