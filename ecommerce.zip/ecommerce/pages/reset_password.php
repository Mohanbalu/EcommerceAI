<?php 
// Including PHPMailer files
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\PHPMailer.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\SMTP.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include('../includes/db.php'); // Your database connection
session_start();

// Check if the token is valid in the URL
if (isset($_GET['token'])) {
    $reset_token = $_GET['token'];

    // Fetch the user corresponding to the reset token
    $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = ?");
    $stmt->execute([$reset_token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $reset_expiry = $user['reset_expiry'];
        $otp_expiry = $user['otp_expiry'];
        $current_time = date("Y-m-d H:i:s");

        // Check if the reset token has expired
        if (strtotime($current_time) > strtotime($reset_expiry)) {
            // Token expired
            $error_message = "Invalid or expired reset token.";
        } else {
            // Proceed to reset the password
            if (isset($_POST['submit'])) {
                $otp = $_POST['otp'];
                $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

                // Fetch OTP and check expiry
                if (strtotime($current_time) <= strtotime($otp_expiry)) {
                    // OTP is valid
                    if ($otp == $user['otp']) {
                        // Update password in the database
                        $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL, otp = NULL, otp_expiry = NULL WHERE reset_token = ?");
                        $stmt->execute([$new_password, $reset_token]);

                        $success_message = "Your password has been successfully reset.";
                    } else {
                        // Invalid OTP
                        $error_message = "Invalid OTP entered.";
                    }
                } else {
                    // OTP expired
                    $error_message = "OTP has expired.";
                }
            }
        }
    } else {
        // Invalid token
        $error_message = "Invalid reset token.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Your Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px 25px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-size: 1em;
            font-weight: 500;
        }
        input {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            margin-top: 10px;
        }
        .error {
            color: #e74c3c;
        }
        .success {
            color: #2ecc71;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Your Password</h2>
        
        <!-- Check if there's an error or success -->
        <?php if (isset($error_message)): ?>
            <p class="message error"><?= htmlspecialchars($error_message); ?></p>
        <?php elseif (isset($success_message)): ?>
            <p class="message success"><?= htmlspecialchars($success_message); ?></p>
        <?php endif; ?>
        
        <?php if (!isset($error_message) && !isset($success_message)): ?>
        <!-- Only show this form if the token is valid -->
        <form method="POST">
            <label for="otp">Enter OTP:</label>
            <input type="text" name="otp" id="otp" required>
            
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" id="new_password" required>
            
            <button type="submit" name="submit">Reset Password</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
