<html>
    <body>

    </body>
    <script>
        if(navigator.geolocation){
            navigator.geolocation.getCurrentPosition(getlatlong)   
        }
        function getlatlong(){
            console.log(data);
        }
    </script>
</html>