<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id']; // Assuming user ID is stored in session

// Fetch the user's cart items
$stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_cost = 0; // Initialize total cost variable

if (empty($cart_items)) {
    header("Location: cart.php");
    exit();
}

// Fetch user's saved address
$stmt = $conn->prepare("SELECT address FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user_data = $stmt->fetch(PDO::FETCH_ASSOC);
$saved_address = $user_data['address'] ?? '';

$product_ids = array_column($cart_items, 'product_id');
$placeholders = implode(',', array_fill(0, count($product_ids), '?'));
$stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute($product_ids);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($products as $product) {
    $quantity = 0;
    foreach ($cart_items as $cart_item) {
        if ($cart_item['product_id'] == $product['id']) {
            $quantity = $cart_item['quantity'];
            break;
        }
    }
    $total_cost += $product['price'] * $quantity; // Add product price * quantity to total cost
}

// Handle order submission
if (isset($_POST['submit_order'])) {
    $selected_address = $_POST['address'];
    $manual_address = $_POST['manual_address'];

    $address = ($selected_address === 'manual') ? $manual_address : $selected_address;
    $phone = $_POST['phone'];

    // Ensure address is not empty
    if (empty($address)) {
        echo "Error: Delivery address is required.";
        exit();
    }

    try {
        $conn->beginTransaction();

        // Create the order in the database
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_cost, address, phone, order_date) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$user_id, $total_cost, $address, $phone]);

        // Get the last inserted order ID
        $order_id = $conn->lastInsertId();

        // Add order items to the order_details table
        foreach ($cart_items as $cart_item) {
            $product_id = $cart_item['product_id'];
            $quantity = $cart_item['quantity'];

            // Insert into order_details
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$order_id, $product_id, $quantity]);

            // Update product stock in the products table
            $stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
            $stmt->execute([$quantity, $product_id, $quantity]);

            if ($stmt->rowCount() === 0) {
                // Rollback if there's not enough stock
                throw new Exception("Insufficient stock for product ID: $product_id");
            }
        }

        // Clear the cart after order submission
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->execute([$user_id]);

        $conn->commit();

        // Redirect to order confirmation page
        header("Location: order_confirmation.php?order_id=$order_id");
        exit();
    } catch (Exception $e) {
        $conn->rollBack();
        echo "Error: " . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            width: 50%;
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }
        .cart-summary {
            margin-bottom: 30px;
        }
        .cart-summary .cart-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .cart-summary .cart-item .item-name {
            font-weight: bold;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group label {
            font-size: 1.1em;
            font-weight: bold;
        }
        .submit-btn {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 1.1em;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        .submit-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Checkout</h2>

        <div class="cart-summary">
            <?php
            foreach ($products as $product) {
                $quantity = 0;
                foreach ($cart_items as $cart_item) {
                    if ($cart_item['product_id'] == $product['id']) {
                        $quantity = $cart_item['quantity'];
                        break;
                    }
                }
                echo "<div class='cart-item'>
                        <div class='item-name'>{$product['name']} x $quantity</div>
                        <div>\${$product['price']} x $quantity = \$" . number_format($product['price'] * $quantity, 2) . "</div>
                      </div>";
            }
            ?>
            <div class="cart-item">
                <div><strong>Total:</strong></div>
                <div><strong>$<?= number_format($total_cost, 2); ?></strong></div>
            </div>
        </div>

        <form method="POST">
    <div class="form-group">
        <label for="address">Delivery Address</label>
        <select id="address" name="address" class="address-select" required onchange="handleAddressChange()">
            <option value="">-- Select Address --</option>
            <?php if (!empty($saved_address)): ?>
                <option value="<?= htmlspecialchars($saved_address); ?>"><?= htmlspecialchars($saved_address); ?></option>
            <?php endif; ?>
            <option value="manual">Enter a new address</option>
        </select>
        <input type="text" name="manual_address" id="manual_address" placeholder="Enter your address" class="manual-address" style="display: none;" />
    </div>

    <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="text" name="phone" id="phone" placeholder="Enter your phone number" required>
    </div>

    <button type="submit" name="submit_order" class="submit-btn">Place Order</button>
</form>

    </div>
</body>
<script>
    function handleAddressChange() {
        const addressSelect = document.getElementById('address');
        const manualAddressInput = document.getElementById('manual_address');

        if (addressSelect.value === 'manual') {
            manualAddressInput.style.display = 'block';
            manualAddressInput.required = true;
        } else {
            manualAddressInput.style.display = 'none';
            manualAddressInput.required = false;
        }
    }
</script>

</html>
