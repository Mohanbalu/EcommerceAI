<?php
session_start();
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\PHPMailer.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\SMTP.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['email'])) {
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
    $otp = rand(100000, 999999);
    $otp_expiry = date("Y-m-d H:i:s", strtotime("+15 minutes"));

    // Store OTP and expiry in session
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_expiry'] = $otp_expiry;

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'mohanbalu1235@gmail.com';
        $mail->Password = 'hzdr ouck rgin mgqo';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('mohanbalu1235@gmail.com', 'Admin');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = 'Your OTP is <strong>' . $otp . '</strong>. It is valid for 15 minutes.';

        $mail->send();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $mail->ErrorInfo]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Email is required.']);
}
