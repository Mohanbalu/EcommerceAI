<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot</title>
    <style>
        #chatbox {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 10px;
            height: 300px;
            overflow-y: scroll;
        }
        #chatbox div {
            margin: 5px;
        }
        .user-msg {
            text-align: right;
            font-weight: bold;
        }
        .bot-msg {
            text-align: left;
        }
        #inputForm {
            display: flex;
        }
        #userInput {
            flex: 1;
        }
    </style>
</head>
<body>
    <div id="chatbox">
        <!-- Chat messages will appear here -->
    </div>

    <form id="inputForm">
        <input type="text" id="userInput" placeholder="Ask me something..." required>
        <button type="submit">Send</button>
    </form>

    <script>
        document.getElementById('inputForm').addEventListener('submit', function(event) {
            event.preventDefault();

            // Get user input
            let userInput = document.getElementById('userInput').value;

            // Display user message
            let userDiv = document.createElement('div');
            userDiv.classList.add('user-msg');
            userDiv.textContent = 'You: ' + userInput;
            document.getElementById('chatbox').appendChild(userDiv);

            // AJAX to get response from backend PHP
            let xhr = new XMLHttpRequest();
            xhr.open('POST', 'chatbot.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Display bot response
                    let botDiv = document.createElement('div');
                    botDiv.classList.add('bot-msg');
                    botDiv.textContent = 'Bot: ' + xhr.responseText;
                    document.getElementById('chatbox').appendChild(botDiv);
                    
                    // Clear the input field
                    document.getElementById('userInput').value = '';
                    document.getElementById('chatbox').scrollTop = document.getElementById('chatbox').scrollHeight;
                }
            };
            xhr.send('user_input=' + encodeURIComponent(userInput));
        });
    </script>
</body>
</html>
