<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = trim($_POST['user_address'] ?? '');
    $phone = trim($_POST['user_phone'] ?? '');
    $payment_method = $_POST['payment_method'] ?? 'cod';
    $payment_details = $payment_method === 'upi' ? trim($_POST['upi_id']) : null;

    // Validate
    if (empty($address) || empty($phone)) {
        $errors[] = "Address and phone number are required.";
    }
    if ($payment_method === 'upi' && empty($payment_details)) {
        $errors[] = "UPI ID is required for UPI payment.";
    }

    if (empty($errors)) {
        // Fetch cart items
        $stmt = $conn->prepare("SELECT product_id, quantity FROM cart WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($cart_items)) {
            $errors[] = "Your cart is empty.";
        } else {
            // Get prices
            $total_cost = 0;
            foreach ($cart_items as $item) {
                $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
                $stmt->execute([$item['product_id']]);
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                $total_cost += $product['price'] * $item['quantity'];
            }

            // Insert into orders
            $stmt = $conn->prepare("INSERT INTO orders (user_id, total_cost, address, phone, order_date, payment_method, payment_details)
                                    VALUES (?, ?, ?, ?, NOW(), ?, ?)");
            $stmt->execute([$user_id, $total_cost, $address, $phone, $payment_method, $payment_details]);

            $order_id = $conn->lastInsertId();

            // Insert into order_details
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, quantity) VALUES (?, ?, ?)");
            foreach ($cart_items as $item) {
                $stmt->execute([$order_id, $item['product_id'], $item['quantity']]);
            }

            // Clear cart
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $stmt->execute([$user_id]);

            $success = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Complete Your Order</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --success-color: #10B981;
            --error-color: #EF4444;
            --border-color: #E5E7EB;
            --text-primary: #111827;
            --text-secondary: #6B7280;
            --bg-primary: #F9FAFB;
            --bg-white: #FFFFFF;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.5;
        }

        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .checkout-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }

        @media (min-width: 768px) {
            .checkout-grid {
                grid-template-columns: 1.5fr 1fr;
            }
        }

        .card {
            background: var(--bg-white);
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        input[type="text"],
        input[type="tel"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.15s ease;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .payment-methods {
            display: grid;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .payment-method {
            position: relative;
            padding: 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.15s ease;
        }

        .payment-method:hover {
            border-color: var(--primary-color);
        }

        .payment-method input[type="radio"] {
            position: absolute;
            opacity: 0;
        }

        .payment-method-label {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .payment-method-icon {
            width: 2rem;
            height: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-primary);
            border-radius: 0.5rem;
        }

        .payment-method input[type="radio"]:checked + .payment-method-label {
            color: var(--primary-color);
        }

        .cart-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            margin-bottom: 1rem;
        }

        .cart-item img {
            width: 5rem;
            height: 5rem;
            object-fit: cover;
            border-radius: 0.5rem;
        }

        .item-details {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .item-price {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }

        .order-summary {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.75rem;
        }

        .summary-row.total {
            font-weight: 600;
            font-size: 1.125rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 2px solid var(--border-color);
        }

        .btn {
            display: block;
            width: 100%;
            padding: 1rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.15s ease;
        }

        .btn:hover {
            background-color: #4338CA;
        }

        .success-message {
            background-color: #ECFDF5;
            border: 1px solid #A7F3D0;
            color: #065F46;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .error-message {
            background-color: #FEF2F2;
            border: 1px solid #FECACA;
            color: #991B1B;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .upi-section {
            margin-top: 1rem;
            padding: 1rem;
            background: var(--bg-primary);
            border-radius: 0.5rem;
            display: none;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($success): ?>
            <div class="success-message fade-in">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" width="20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                </svg>
                Order placed successfully! Thank you for your purchase.
            </div>
        <?php endif; ?>

        <?php foreach ($errors as $error): ?>
            <div class="error-message fade-in">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" width="20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                </svg>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endforeach; ?>

        <div class="checkout-grid">
            <div class="card">
                <h2 class="section-title">Shipping Information</h2>
                <form method="post" id="checkout-form">
                    <div class="form-group">
                        <label for="user_address">Delivery Address</label>
                        <textarea 
                            name="user_address" 
                            id="user_address" 
                            rows="3" 
                            required
                            placeholder="Enter your complete delivery address"
                        ><?= htmlspecialchars($_POST['user_address'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="user_phone">Phone Number</label>
                        <input 
                            type="tel" 
                            name="user_phone" 
                            id="user_phone" 
                            required 
                            placeholder="Enter your contact number"
                            value="<?= htmlspecialchars($_POST['user_phone'] ?? '') ?>"
                        >
                    </div>

                    <h2 class="section-title">Payment Method</h2>
                    <div class="payment-methods">
                        <div class="payment-method">
                            <input 
                                type="radio" 
                                name="payment_method" 
                                id="cod" 
                                value="cod" 
                                <?= (($_POST['payment_method'] ?? 'cod') === 'cod') ? 'checked' : '' ?>
                            >
                            <label for="cod" class="payment-method-label">
                                <div class="payment-method-icon">💵</div>
                                <div>
                                    <div>Cash on Delivery</div>
                                    <div class="text-sm text-gray-500">Pay when you receive</div>
                                </div>
                            </label>
                        </div>

                        <div class="payment-method">
                            <input 
                                type="radio" 
                                name="payment_method" 
                                id="upi" 
                                value="upi"
                                <?= (($_POST['payment_method'] ?? '') === 'upi') ? 'checked' : '' ?>
                            >
                            <label for="upi" class="payment-method-label">
                                <div class="payment-method-icon">📱</div>
                                <div>
                                    <div>UPI Payment</div>
                                    <div class="text-sm text-gray-500">Pay using UPI</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="upi-section" id="upi-section">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label for="upi_id">UPI ID</label>
                            <input 
                                type="text" 
                                name="upi_id" 
                                id="upi_id" 
                                placeholder="Enter your UPI ID"
                                value="<?= htmlspecialchars($_POST['upi_id'] ?? '') ?>"
                            >
                        </div>
                    </div>

                    <button type="submit" class="btn">Place Order</button>
                </form>
            </div>

            <div class="card">
                <h2 class="section-title">Order Summary</h2>
                <?php
                $stmt = $conn->prepare("SELECT p.name, p.image, p.price, c.quantity 
                                      FROM cart c 
                                      JOIN products p ON c.product_id = p.id 
                                      WHERE c.user_id = ?");
                $stmt->execute([$user_id]);
                $cart_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $total = 0;

                if ($cart_products):
                    foreach ($cart_products as $item):
                        $total += $item['price'] * $item['quantity'];
                ?>
                    <div class="cart-item fade-in">
                        <img src="../uploads/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                        <div class="item-details">
                            <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                            <div class="item-price">
                                <?= $item['quantity'] ?> × ₹<?= number_format($item['price'], 2) ?>
                            </div>
                        </div>
                    </div>
                <?php 
                    endforeach;
                ?>
                    <div class="order-summary">
                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span>₹<?= number_format($total, 2) ?></span>
                        </div>
                        <div class="summary-row">
                            <span>Shipping</span>
                            <span>Free</span>
                        </div>
                        <div class="summary-row total">
                            <span>Total</span>
                            <span>₹<?= number_format($total, 2) ?></span>
                        </div>
                    </div>
                <?php else: ?>
                    <p>Your cart is empty.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Handle payment method selection
        document.querySelectorAll('input[name="payment_method"]').forEach(input => {
            input.addEventListener('change', function() {
                const upiSection = document.getElementById('upi-section');
                if (this.value === 'upi') {
                    upiSection.style.display = 'block';
                    upiSection.classList.add('fade-in');
                } else {
                    upiSection.style.display = 'none';
                }
            });
        });

        // Initialize payment method display
        document.addEventListener('DOMContentLoaded', function() {
            const selectedMethod = document.querySelector('input[name="payment_method"]:checked');
            if (selectedMethod && selectedMethod.value === 'upi') {
                document.getElementById('upi-section').style.display = 'block';
            }
        });

        // Form validation
        document.getElementById('checkout-form').addEventListener('submit', function(e) {
            const address = document.getElementById('user_address').value.trim();
            const phone = document.getElementById('user_phone').value.trim();
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
            const upiId = document.getElementById('upi_id').value.trim();

            if (!address || !phone) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return;
            }

            if (paymentMethod === 'upi' && !upiId) {
                e.preventDefault();
                alert('Please enter your UPI ID.');
                return;
            }

            // Basic phone number validation
            const phoneRegex = /^\d{10}$/;
            if (!phoneRegex.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid 10-digit phone number.');
                return;
            }
        });
    </script>
</body>
</html>