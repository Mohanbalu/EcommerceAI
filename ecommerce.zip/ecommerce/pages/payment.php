<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id']; // Assuming user ID is stored in session

// Fetch user's cart items and product details
$stmt = $conn->prepare("
    SELECT 
        p.id AS product_id, p.name, p.image, p.price, c.quantity 
    FROM 
        cart c 
    JOIN 
        products p 
    ON 
        c.product_id = p.id 
    WHERE 
        c.user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_cost = 0;

if (empty($cart_items)) {
    header("Location: cart.php");
    exit();
}

// Calculate total cost
foreach ($cart_items as $item) {
    $total_cost += $item['price'] * $item['quantity'];
}

// Fetch user's address and phone number
$stmt = $conn->prepare("SELECT address, phone FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user_details = $stmt->fetch(PDO::FETCH_ASSOC);

$user_address = $user_details['address'];
$user_phone = $user_details['phone'];

// Handle form submission for payment
if (isset($_POST['submit_payment'])) {
    $payment_method = $_POST['payment_method'];
    $payment_details = '';  // Placeholder for additional payment details

    if ($payment_method === 'cod') {
        $payment_details = 'Cash on Delivery';
    } elseif ($payment_method === 'upi') {
        $payment_details = $_POST['upi_id'] ?? '';
    } elseif ($payment_method === 'debit_card') {
        $payment_details = 'Card ending with ' . substr($_POST['card_number'], -4);
    }

    try {
        // Save payment details and update order status (optional)
        // Here you need to insert the order into the orders table
        // Assume orders table and order details (including cart) exists
        
        $conn->beginTransaction(); // Starting the transaction
        // Insert order into orders table
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_cost, payment_method, payment_details, address, phone) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $total_cost, $payment_method, $payment_details, $user_address, $user_phone]);
        $order_id = $conn->lastInsertId(); // Get the last inserted order ID
        
        // Now insert the cart items into order_details table
        foreach ($cart_items as $item) {
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$order_id, $item['product_id'], $item['quantity']]);
        }
        
        // Commit transaction
        $conn->commit();

        // Redirect to order confirmation page
        header("Location: order_confirmation.php?order_id=" . $order_id);
        exit();
    } catch (Exception $e) {
        $conn->rollBack(); // Rollback transaction on error
        echo "Error: " . htmlspecialchars($e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        .cart-item img {
            width: 60px;
            height: auto;
            margin-right: 15px;
        }
        .cart-item div {
            flex: 1;
        }
        .total-cost {
            font-size: 1.4em;
            font-weight: bold;
            margin-top: 15px;
            text-align: right;
        }
        .payment-options {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
        }
        .payment-option {
            margin-bottom: 15px;
        }
        .payment-option input[type="radio"] {
            margin-right: 10px;
        }
        .payment-details {
            display: none;
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .submit-btn {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 1.1em;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        .submit-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Cart</h2>
        
        <?php foreach ($cart_items as $item): ?>
            <div class="cart-item">
                <img src="../product_images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                <div>
                    <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                    <?= htmlspecialchars(number_format($item['price'], 2)) ?> x <?= $item['quantity'] ?> = 
                    <?= htmlspecialchars(number_format($item['price'] * $item['quantity'], 2)) ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="total-cost">
            Total Cost: <?= number_format($total_cost, 2); ?>
        </div>

        <h3>Delivery Address</h3>
        <p><strong>Address:</strong> <?= htmlspecialchars($user_address) ?></p>
        <p><strong>Phone:</strong> <?= htmlspecialchars($user_phone) ?></p>
        
        <form method="POST" action="payment.php">
            <h3>Choose Payment Method</h3>
            <div class="payment-options">
                <div class="payment-option">
                    <input type="radio" name="payment_method" id="cod" value="cod" required>
                    <label for="cod">Cash on Delivery</label>
                </div>
                <div class="payment-option">
                    <input type="radio" name="payment_method" id="upi" value="upi">
                    <label for="upi">UPI (Google Pay, PhonePe, etc.)</label>
                </div>
                <div class="payment-option">
                    <input type="radio" name="payment_method" id="debit_card" value="debit_card">
                    <label for="debit_card">Debit Card</label>
                </div>
            </div>

            <div id="payment_details" class="payment-details">
                <div id="upi_input" style="display: none;">
                    <div class="form-group">
                        <label for="upi_id">Enter UPI ID</label>
                        <input type="text" name="upi_id" id="upi_id" placeholder="Enter your UPI ID">
                    </div>
                </div>

                <div id="debit_card_input" style="display: none;">
                    <div class="form-group">
                        <label for="card_number">Card Number</label>
                        <input type="text" name="card_number" id="card_number" placeholder="Enter your card number">
                    </div>
                    <div class="form-group">
                        <label for="expiry">Expiry Date</label>
                        <input type="month" name="expiry" id="expiry">
                    </div>
                    <div class="form-group">
                        <label for="cvv">CVV</label>
                        <input type="text" name="cvv" id="cvv" placeholder="Enter CVV">
                    </div>
                </div>
            </div>

            <button type="submit" name="submit_payment" class="submit-btn">Proceed to Payment</button>
        </form>
    </div>

    <script>
        const paymentMethodOptions = document.querySelectorAll('input[name="payment_method"]');
        const paymentDetails = document.getElementById('payment_details');
        const upiInput = document.getElementById('upi_input');
        const debitCardInput = document.getElementById('debit_card_input');

        paymentMethodOptions.forEach((option) => {
            option.addEventListener('change', () => {
                paymentDetails.style.display = 'none';
                upiInput.style.display = 'none';
                debitCardInput.style.display = 'none';

                if (option.value === 'upi') {
                    paymentDetails.style.display = 'block';
                    upiInput.style.display = 'block';
                } else if (option.value === 'debit_card') {
                    paymentDetails.style.display = 'block';
                    debitCardInput.style.display = 'block';
                } else {
                    paymentDetails.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
