<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Fetch current user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        // Basic Information Update
        if (isset($_POST['update_basic'])) {
            $full_name = trim($_POST['full_name']);
            $email = trim($_POST['email']);
            $location = trim($_POST['location']);
            $pincode = trim($_POST['pincode']);

            // Validate email format
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email format");
            }

            // Check if email exists for other users
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $user_id]);
            if ($stmt->fetch()) {
                throw new Exception("Email already in use");
            }

            $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, location = ?, pincode = ? WHERE id = ?");
            $stmt->execute([$full_name, $email, $location, $pincode, $user_id]);
            $success_message = "Basic information updated successfully!";
        }

        // Password Update
        if (isset($_POST['update_password'])) {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            // Verify current password
            if (!password_verify($current_password, $user['password'])) {
                throw new Exception("Current password is incorrect");
            }

            // Validate new password
            if (strlen($new_password) < 8) {
                throw new Exception("New password must be at least 8 characters long");
            }

            if ($new_password !== $confirm_password) {
                throw new Exception("New passwords do not match");
            }

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $user_id]);
            $success_message = "Password updated successfully!";
        }

        // Address Management
        if (isset($_POST['update_address'])) {
            $addresses = json_decode($user['address'], true) ?: [];
            $new_address = trim($_POST['new_address']);
            
            if (!empty($new_address) && !in_array($new_address, $addresses)) {
                $addresses[] = $new_address;
                $stmt = $conn->prepare("UPDATE users SET address = ? WHERE id = ?");
                $stmt->execute([json_encode($addresses), $user_id]);
                $success_message = "Address added successfully!";
            }
        }

        if (isset($_POST['remove_address'])) {
            $addresses = json_decode($user['address'], true) ?: [];
            $index = $_POST['address_index'];
            
            if (isset($addresses[$index])) {
                array_splice($addresses, $index, 1);
                $stmt = $conn->prepare("UPDATE users SET address = ? WHERE id = ?");
                $stmt->execute([json_encode($addresses), $user_id]);
                $success_message = "Address removed successfully!";
            }
        }

        // Phone Number Management
        if (isset($_POST['update_phone'])) {
            $phones = json_decode($user['phone'], true) ?: [];
            $new_phone = trim($_POST['new_phone']);
            
            if (!empty($new_phone) && !in_array($new_phone, $phones)) {
                if (!preg_match("/^[0-9]{10}$/", $new_phone)) {
                    throw new Exception("Invalid phone number format");
                }
                $phones[] = $new_phone;
                $stmt = $conn->prepare("UPDATE users SET phone = ? WHERE id = ?");
                $stmt->execute([json_encode($phones), $user_id]);
                $success_message = "Phone number added successfully!";
            }
        }

        if (isset($_POST['remove_phone'])) {
            $phones = json_decode($user['phone'], true) ?: [];
            $index = $_POST['phone_index'];
            
            if (isset($phones[$index])) {
                array_splice($phones, $index, 1);
                $stmt = $conn->prepare("UPDATE users SET phone = ? WHERE id = ?");
                $stmt->execute([json_encode($phones), $user_id]);
                $success_message = "Phone number removed successfully!";
            }
        }

        $conn->commit();
        
        // Refresh user data after updates
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        $conn->rollBack();
        $error_message = $e->getMessage();
    }
}

$addresses = json_decode($user['address'], true) ?: [];
$phones = json_decode($user['phone'], true) ?: [];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Settings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --success-color: #059669;
            --error-color: #dc2626;
            --border-color: #e5e7eb;
            --text-color: #1f2937;
            --text-secondary: #6b7280;
            --background-color: #f3f4f6;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: var(--background-color);
            color: var(--text-color);
            line-height: 1.5;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .settings-header {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .settings-header h1 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }

        .settings-section {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .settings-section h2 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--border-color);
        }

        .form-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            font-size: 0.875rem;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            transition: all 0.2s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 6px;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        button:hover {
            background: var(--primary-hover);
        }

        .message {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
        }

        .success {
            background: #dcfce7;
            color: var(--success-color);
        }

        .error {
            background: #fee2e2;
            color: var(--error-color);
        }

        .list-group {
            margin-bottom: 1rem;
        }

        .list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            background: var(--background-color);
            border-radius: 6px;
            margin-bottom: 0.5rem;
        }

        .remove-btn {
            background: var(--error-color);
            color: white;
            border: none;
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            font-size: 0.75rem;
            cursor: pointer;
        }

        .remove-btn:hover {
            background: #b91c1c;
        }

        @media (max-width: 640px) {
            .settings-section {
                padding: 1rem;
            }

            button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="settings-header">
            <h1>Account Settings</h1>
        </div>

        <?php if ($success_message): ?>
            <div class="message success"><?= htmlspecialchars($success_message) ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="message error"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <!-- Basic Information -->
        <div class="settings-section">
            <h2>Basic Information</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" value="<?= htmlspecialchars($user['location']) ?>">
                </div>

                <div class="form-group">
                    <label for="pincode">Pincode</label>
                    <input type="text" id="pincode" name="pincode" value="<?= htmlspecialchars($user['pincode']) ?>">
                </div>

                <button type="submit" name="update_basic">Update Basic Information</button>
            </form>
        </div>

        <!-- Password Change -->
        <div class="settings-section">
            <h2>Change Password</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>

                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>

                <button type="submit" name="update_password">Change Password</button>
            </form>
        </div>

        <!-- Address Management -->
        <div class="settings-section">
            <h2>Manage Addresses</h2>
            
            <div class="list-group">
                <?php foreach ($addresses as $index => $address): ?>
                    <div class="list-item">
                        <span><?= htmlspecialchars($address) ?></span>
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="address_index" value="<?= $index ?>">
                            <button type="submit" name="remove_address" class="remove-btn">Remove</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="new_address">Add New Address</label>
                    <input type="text" id="new_address" name="new_address" required>
                </div>
                <button type="submit" name="update_address">Add Address</button>
            </form>
        </div>

        <!-- Phone Numbers -->
        <div class="settings-section">
            <h2>Manage Phone Numbers</h2>
            
            <div class="list-group">
                <?php foreach ($phones as $index => $phone): ?>
                    <div class="list-item">
                        <span><?= htmlspecialchars($phone) ?></span>
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="phone_index" value="<?= $index ?>">
                            <button type="submit" name="remove_phone" class="remove-btn">Remove</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="new_phone">Add New Phone Number</label>
                    <input type="text" id="new_phone" name="new_phone" placeholder="10-digit number" required>
                </div>
                <button type="submit" name="update_phone">Add Phone Number</button>
            </form>
        </div>
    </div>
</body>
</html>