<?php
// process-chatbot.php

// Include database connection
require_once 'includes/db.php';

// Function to process user input and check for a valid product name
function process_message($message) {
    global $conn;
    if (strpos(strtolower($message), 'order ') === 0) {
        $productName = substr($message, 6);
    
        $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE :product_name LIMIT 1");
        $stmt->execute([':product_name' => '%' . $productName . '%']);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if ($product) {
            // Add product to the cart for the logged-in user
            if (isset($_SESSION['user_id'])) {
                $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id) VALUES (:user_id, :product_id)");
                $stmt->execute([
                    ':user_id' => $_SESSION['user_id'],
                    ':product_id' => $product['id']
                ]);
                return [
                    'reply' => 'Your order for ' . htmlspecialchars($product['name']) . ' has been added to the cart.'
                ];
            }
            return [
                'reply' => 'Please log in to place an order.'
            ];
        }
    }
    
    return ['reply' => 'I didn\'t understand that. Try saying "order <product_name>" to place an order.'];
}

// Capture the user message
$data = json_decode(file_get_contents('php://input'), true);
if (isset($data['message'])) {
    $userMessage = trim($data['message']);
    $response = process_message($userMessage);
    echo json_encode($response);
} else {
    echo json_encode(['reply' => 'Sorry, I could not understand your request.']);
}
?>
