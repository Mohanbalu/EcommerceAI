<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="payment_report.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Order ID', 'Order Date', 'Delivery Address', 'Phone', 'Total Cost', 'Payment Method', 'Payment Details']);

$stmt = $conn->prepare("SELECT id AS order_id, order_date, address, phone, total_cost, payment_method, payment_details 
                        FROM orders 
                        WHERE user_id = ? 
                        ORDER BY order_date DESC");
$stmt->execute([$_SESSION['user_id']]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, $row);
}

fclose($output);
exit();
