<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id']; // Assuming user ID is stored in session

// Fetch the last order placed by the user
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC LIMIT 1");
$stmt->execute([$user_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Error: Order not found.";
    exit();
}

// Fetch order details (products) from the order
$stmt = $conn->prepare("SELECT od.quantity, p.name, p.price 
                        FROM order_details od 
                        JOIN products p ON od.product_id = p.id 
                        WHERE od.order_id = ?");
$stmt->execute([$order['id']]);
$order_details = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_cost = $order['total_cost']; // Total cost from the order

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }
        .order-summary {
            font-size: 1.2em;
            margin-bottom: 30px;
        }
        .order-summary div {
            margin-bottom: 10px;
        }
        .order-details {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            text-align: left;
        }
        .order-details th, .order-details td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        .order-details th {
            background-color: #f8f9fa;
        }
        .order-details td {
            font-size: 1em;
        }
        .total-cost {
            font-size: 1.5em;
            font-weight: bold;
            margin-top: 20px;
            text-align: center;
        }
        .back-to-shop {
            display: block;
            text-align: center;
            margin-top: 30px;
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-to-shop:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Order Confirmation</h2>
        <div class="order-summary">
            <div><strong>Order ID:</strong> #<?= htmlspecialchars($order['id']); ?></div>
            <div><strong>Order Date:</strong> <?= htmlspecialchars($order['order_date']); ?></div>
            <div><strong>Delivery Address:</strong> <?= htmlspecialchars($order['address']); ?></div>
            <div><strong>Phone Number:</strong> <?= htmlspecialchars($order['phone']); ?></div>
        </div>

        <table class="order-details">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($order_details as $item) : ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td><?= number_format($item['price'], 2); ?></td>
                        <td><?= htmlspecialchars($item['quantity']); ?></td>
                        <td><?= number_format($item['price'] * $item['quantity'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total-cost">
            Total: $<?= number_format($total_cost, 2); ?>
        </div>

        <a href="../index.php" class="back-to-shop">Back to Shop</a>
    </div>
</body>
</html>
