<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

if (!isset($_GET['order_id'])) {
    header("Location: index.php"); // Redirect to home if no order ID is provided
    exit();
}

$order_id = $_GET['order_id'];
$user_id = $_SESSION['user_id'];

// Fetch order details
$stmt = $conn->prepare("SELECT total_cost, payment_method, payment_details, address, phone FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "<p>Order not found.</p>";
    exit();
}

// Fetch order items
$stmt = $conn->prepare("SELECT p.name, p.image, p.price, od.quantity FROM order_details od JOIN products p ON od.product_id = p.id WHERE od.order_id = ?");
$stmt->execute([$order_id]);
$order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            width: 50%;
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            color: #28a745;
        }
        .order-details, .cart-item {
            text-align: left;
            margin: 15px 0;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        .cart-item img {
            width: 60px;
            height: auto;
            margin-right: 15px;
        }
        .cart-item div {
            flex: 1;
        }
        .order-summary {
            font-size: 1.2em;
            font-weight: bold;
            margin-top: 15px;
        }
        .home-btn {
            display: inline-block;
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 1.1em;
        }
        .home-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Thank You for Your Order!</h2>
        <p>Your order has been successfully placed.</p>
        
        <div class="order-details">
            <h3>Order Summary</h3>
            <p><strong>Order ID:</strong> <?= htmlspecialchars($order_id) ?></p>
            <p><strong>Total Cost:</strong> <?= number_format($order['total_cost'], 2) ?></p>
            <p><strong>Payment Method:</strong> <?= htmlspecialchars(ucwords(str_replace('_', ' ', $order['payment_method']))) ?></p>
            <p><strong>Payment Details:</strong> <?= htmlspecialchars($order['payment_details']) ?></p>
            <p><strong>Delivery Address:</strong> <?= htmlspecialchars($order['address']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
        </div>
        
        <h3>Ordered Items</h3>
        <?php foreach ($order_items as $item): ?>
            <div class="cart-item">
                <img src="../product_images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                <div>
                    <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                    <?= htmlspecialchars(number_format($item['price'], 2)) ?> x <?= $item['quantity'] ?> = 
                    <?= htmlspecialchars(number_format($item['price'] * $item['quantity'], 2)) ?>
                </div>
            </div>
        <?php endforeach; ?>

        <a href="../index.php" class="home-btn">Continue Shopping</a>
    </div>
</body>
</html>
