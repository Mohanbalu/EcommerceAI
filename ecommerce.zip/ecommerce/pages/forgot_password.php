<?php 
// Including PHPMailer files
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\PHPMailer.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\SMTP.php';
require_once 'C:\xampp\htdocs\ecommerce\PHPMailer-master\src\Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include('../includes/db.php'); // Your database connection
session_start();

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Generate a 6-digit OTP
        $otp = rand(100000, 999999);
        $otp_expiry = date("Y-m-d H:i:s", strtotime("+15 minutes")); // OTP valid for 15 minutes

        // Generate reset token and set expiry
        $reset_token = bin2hex(random_bytes(16)); // 32 character token
        $reset_expiry = date("Y-m-d H:i:s", strtotime("+1 hour")); // Token valid for 1 hour

        // Update OTP, expiry, reset_token, and reset_expiry in the database
        $stmt = $conn->prepare("UPDATE users SET otp = ?, otp_expiry = ?, reset_token = ?, reset_expiry = ? WHERE email = ?");
        $stmt->execute([$otp, $otp_expiry, $reset_token, $reset_expiry, $email]);

        // Prepare to send email with OTP and reset link
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mohanbalu1235@gmail.com'; // Your email address
            $mail->Password = 'hzdr ouck rgin mgqo'; // Your email app-specific password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipient and email settings
            $mail->setFrom('mohanbalu1235@gmail.com', 'Admin');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Link';
            $mail->Body    = 'Click <a href="http://localhost/ecommerce/pages/reset_password.php?token=' . $reset_token . '">here</a> to reset your password.<br>Your OTP is: ' . $otp . '. It will expire in 15 minutes.';

            // Send the email
            $mail->send();

            $success_message = "An OTP and password reset link have been sent to your email address.";
        } catch (Exception $e) {
            $error_message = "Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        // If email does not exist in the database
        $error_message = "No account found with that email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 20px 25px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        .container form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-size: 1em;
            font-weight: 500;
        }
        input {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            margin-top: 10px;
        }
        .error {
            color: #e74c3c;
        }
        .success {
            color: #2ecc71;
        }
        .reset-link {
            margin-top: 10px;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <form method="POST">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <button type="submit" name="submit">Send Reset Link</button>
        </form>
        <?php if (isset($error_message)): ?>
            <p class="message error"><?= htmlspecialchars($error_message); ?></p>
        <?php elseif (isset($success_message)): ?>
            <p class="message success"><?= htmlspecialchars($success_message); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
