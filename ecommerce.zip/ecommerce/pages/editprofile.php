<?php
session_start();
include '../includes/db.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: pages/login.php");
    exit();
}

// Fetch user data from the database
$stmt = $conn->prepare("SELECT full_name, email, profile_picture, password FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Update user profile
if (isset($_POST['update_profile'])) {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];
    $new_password = $_POST['password'];
    
    // Check if the email is different from the current one
    if ($new_email !== $user['email']) {
        // Email check to see if the new email already exists
        $email_check = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $email_check->execute([$new_email]);
        $email_exists = $email_check->fetchColumn();

        if ($email_exists > 0) {
            $_SESSION['error_message'] = 'This email is already in use. Please choose a different one.';
        } else {
            // Proceed with the update as the email is unique
            $hashed_password = !empty($new_password) ? password_hash($new_password, PASSWORD_DEFAULT) : $user['password'];

            // Handle profile picture upload
            $new_profile_picture = $user['profile_picture'];
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
                if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                    $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
                }
            }

            // Update the user record in the database with new email
            $update_sql = "UPDATE users SET full_name = ?, email = ?, profile_picture = ?, password = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->execute([$new_name, $new_email, $new_profile_picture, $hashed_password, $_SESSION['user_id']]);

            // Update session data
            $_SESSION['name'] = $new_name;
            $_SESSION['profile_picture'] = $new_profile_picture;
            $_SESSION['success_message'] = 'Profile updated successfully!';
            header("Location: profile.php");
            exit();
        }
    } else {
        // If the email is not changing, just update the name, password, and profile picture
        $hashed_password = !empty($new_password) ? password_hash($new_password, PASSWORD_DEFAULT) : $user['password'];

        // Handle profile picture upload
        $new_profile_picture = $user['profile_picture'];
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
            }
        }

        // Update database with new details
        $update_sql = "UPDATE users SET full_name = ?, profile_picture = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->execute([$new_name, $new_profile_picture, $hashed_password, $_SESSION['user_id']]);

        // Update session data
        $_SESSION['name'] = $new_name;
        $_SESSION['profile_picture'] = $new_profile_picture;
        $_SESSION['success_message'] = 'Profile updated successfully!';
        header("Location: profile.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --primary-hover: #4338CA;
            --error-color: #DC2626;
            --success-color: #059669;
            --border-color: #E5E7EB;
            --text-primary: #111827;
            --text-secondary: #6B7280;
            --bg-primary: #F9FAFB;
            --bg-white: #FFFFFF;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.5;
            color: var(--text-primary);
            background-color: var(--bg-primary);
        }

        header {
            background-color: var(--bg-white);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-color);
            text-decoration: none;
        }

        nav {
            display: flex;
            gap: 1.5rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .main-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: var(--bg-white);
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .page-title {
            font-size: 1.875rem;
            font-weight: 600;
            margin-bottom: 2rem;
            color: var(--text-primary);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .input-field {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.2s ease;
        }

        .input-field:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .file-input-wrapper {
            position: relative;
            margin-top: 0.5rem;
        }

        .file-input-label {
            display: inline-block;
            padding: 0.75rem 1rem;
            background-color: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .file-input-label:hover {
            background-color: #F3F4F6;
        }

        .submit-button {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .submit-button:hover {
            background-color: var(--primary-hover);
        }

        .alert {
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .alert-error {
            background-color: #FEE2E2;
            border: 1px solid #FCA5A5;
            color: var(--error-color);
        }

        .alert-success {
            background-color: #D1FAE5;
            border: 1px solid #6EE7B7;
            color: var(--success-color);
        }

        .profile-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
        }

        footer {
            background-color: var(--bg-white);
            border-top: 1px solid var(--border-color);
            padding: 1.5rem;
            text-align: center;
            color: var(--text-secondary);
            margin-top: 4rem;
        }

        @media (max-width: 768px) {
            .main-container {
                margin: 1rem;
                padding: 1.5rem;
            }

            .page-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <a href="../index.php" class="logo">Our Store</a>
            <nav>
                <a href="../index.php" class="nav-link">Home</a>
                <a href="profile.php" class="nav-link">Profile</a>
                <a href="logout.php" class="nav-link">Logout</a>
            </nav>
        </div>
    </header>

    <div class="main-container">
        <h1 class="page-title">Edit Your Profile</h1>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php 
                    echo $_SESSION['error_message'];
                    unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                    echo $_SESSION['success_message'];
                    unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <?php if ($user['profile_picture']): ?>
                <img src="uploads/<?= htmlspecialchars($user['profile_picture']); ?>" 
                     alt="Profile Picture" 
                     class="profile-preview" 
                     id="profile-preview">
            <?php endif; ?>

            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" 
                       name="name" 
                       id="name" 
                       class="input-field"
                       value="<?= htmlspecialchars($user['full_name']); ?>" 
                       required>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" 
                       name="email" 
                       id="email" 
                       class="input-field"
                       value="<?= htmlspecialchars($user['email']); ?>" 
                       required>
            </div>

            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" 
                       name="password" 
                       id="password" 
                       class="input-field"
                       placeholder="Leave blank to keep current password">
            </div>

            <div class="form-group">
                <label for="profile_picture">Profile Picture</label>
                <div class="file-input-wrapper">
                    <label class="file-input-label">
                        Choose File
                        <input type="file" 
                               name="profile_picture" 
                               id="profile_picture" 
                               accept="image/*"
                               style="display: none;"
                               onchange="previewImage(this)">
                    </label>
                </div>
            </div>

            <button type="submit" name="update_profile" class="submit-button">
                Update Profile
            </button>
        </form>
    </div>

    <footer>
        <p>&copy; <?= date('Y'); ?> Our Store. All rights reserved.</p>
    </footer>

    <script>
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('profile-preview');
                    if (preview) {
                        preview.src = e.target.result;
                    } else {
                        const newPreview = document.createElement('img');
                        newPreview.src = e.target.result;
                        newPreview.id = 'profile-preview';
                        newPreview.className = 'profile-preview';
                        input.parentElement.parentElement.parentElement.insertBefore(
                            newPreview, 
                            input.parentElement.parentElement
                        );
                    }
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>
</html>