<?php
session_start();
include '../includes/db.php';

// Redirect to login page if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: pages/login.php");
    exit();
}

// Fetch user data from the database
$stmt = $conn->prepare("SELECT full_name, email, profile_picture, password FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Update user profile
if (isset($_POST['update_profile'])) {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];
    $new_password = $_POST['password'];
    
    // Check if the email is different from the current one
    if ($new_email !== $user['email']) {
        // Email check to see if the new email already exists
        $email_check = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $email_check->execute([$new_email]);
        $email_exists = $email_check->fetchColumn();

        if ($email_exists > 0) {
            // Email is already taken, alert the user
            echo "<script>alert('This email is already in use. Please choose a different one.');</script>";
        } else {
            // Proceed with the update as the email is unique
            $hashed_password = !empty($new_password) ? password_hash($new_password, PASSWORD_DEFAULT) : $user['password'];

            // Handle profile picture upload
            $new_profile_picture = $user['profile_picture'];
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
                if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                    $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
                }
            }

            // Update the user record in the database with new email
            $update_sql = "UPDATE users SET full_name = ?, email = ?, profile_picture = ?, password = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->execute([$new_name, $new_email, $new_profile_picture, $hashed_password, $_SESSION['user_id']]);

            // Update session data
            $_SESSION['name'] = $new_name;
            $_SESSION['profile_picture'] = $new_profile_picture;
            header("Location: profile.php");
            exit();
        }
    } else {
        // If the email is not changing, just update the name, password, and profile picture
        $hashed_password = !empty($new_password) ? password_hash($new_password, PASSWORD_DEFAULT) : $user['password'];

        // Handle profile picture upload
        $new_profile_picture = $user['profile_picture'];
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                $new_profile_picture = basename($_FILES["profile_picture"]["name"]);
            }
        }

        // Update database with new details (full name, password, and profile picture)
        $update_sql = "UPDATE users SET full_name = ?, profile_picture = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->execute([$new_name, $new_profile_picture, $hashed_password, $_SESSION['user_id']]);

        // Update session data
        $_SESSION['name'] = $new_name;
        $_SESSION['profile_picture'] = $new_profile_picture;
        header("Location: profile.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 {
            margin: 0;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .main-container {
            width: 60%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        form {
            display: grid;
            gap: 15px;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="file"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
        }

        button[type="submit"] {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

    </style>
</head>
<body>
<header>
    <div class="header-container">
        <h1>Welcome to Our Store</h1>
        <nav>
            <a href="index.php" class="nav-link">Home</a>
            <a href="../index.php" class="nav-link">Logout</a>
        </nav>
    </div>
</header>

<div class="main-container">
    <main>
        <h2>Edit Your Profile</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="name">Full Name:</label>
            <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['full_name']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']); ?>" required>

            <label for="password">New Password:</label>
            <input type="password" name="password" id="password" placeholder="Leave blank to keep current password">

            <label for="profile_picture">Profile Picture:</label>
            <input type="file" name="profile_picture" id="profile_picture">

            <button type="submit" name="update_profile">Update Profile</button>
        </form>
    </main>
</div>

<footer>
    <p>&copy; <?= date('Y'); ?> Online Store. All rights reserved.</p>
</footer>

</body>
</html>
