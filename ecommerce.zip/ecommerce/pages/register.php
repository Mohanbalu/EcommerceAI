<?php
include('../includes/db.php');
session_start();

if (isset($_POST['register'])) {
    try {
        // Sanitize inputs
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $full_name = filter_var($_POST['full_name'], FILTER_SANITIZE_STRING);
        $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
        $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
        $pincode = isset($_POST['pincode']) ? filter_var($_POST['pincode'], FILTER_SANITIZE_STRING) : null;
        $location = isset($_POST['location']) ? filter_var($_POST['location'], FILTER_SANITIZE_STRING) : null;
        $role = 'user';

        $profile_picture_path = null;
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == UPLOAD_ERR_OK) {
            $target_dir = "../uploads/";
            $target_file = $target_dir . basename($_FILES['profile_picture']['name']);
            $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            
            // Validate file type and size
            $check = getimagesize($_FILES['profile_picture']['tmp_name']);
            if ($check && in_array($image_file_type, ['jpg', 'png', 'jpeg'])) {
                move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file);
                $profile_picture_path = $target_file;
            } else {
                $error_message = "Invalid profile picture format!";
            }
        }

        if (!preg_match("/^[a-zA-Z\s]+$/", $full_name)) {
            $error_message = "Full name should contain only letters and spaces!";
        } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
            $error_message = "Phone number must be a valid 10-digit number!";
        } elseif (strlen($address) < 5) {
            $error_message = "Address is too short!";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Invalid email format!";
        } else {
            // Check if email already exists
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                $error_message = "Email is already registered!";
            } else {
                // Hash password
                $password_hashed = password_hash($password, PASSWORD_DEFAULT);
                // Insert user into database
                $stmt = $conn->prepare("INSERT INTO users (email, password, role, full_name, phone, address, pincode, location, profile_picture) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                if ($stmt->execute([$email, $password_hashed, $role, $full_name, $phone, $address, $pincode, $location, $profile_picture_path])) {
                    $_SESSION['user_id'] = $conn->lastInsertId();
                    echo "<script>alert('Registration successful! Redirecting to the main page.');</script>";
                    header("Location: ../index.php");
                    exit();
                } else {
                    $error_message = "Registration failed due to a database error!";
                }
            }
        }
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
        $error_message = "An error occurred during registration!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        label {
            font-size: 1.1em;
            margin-bottom: 5px;
            display: block;
        }
        input[type="email"],
        input[type="password"],
        input[type="text"],
        input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            font-size: 1.1em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .error-message {
            color: #e74c3c;
            font-size: 1em;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        /* Same styles as before, keeping it simple */
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <form method="POST" enctype="multipart/form-data">
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Full Name:</label>
            <input type="text" name="full_name" required>

            <label>Phone Number:</label>
            <input type="tel" name="phone" pattern="[0-9]{10}" title="Enter a valid 10-digit phone number" required>

            <label>Address:</label>
            <textarea name="address" rows="3" required></textarea>

            <label>Pincode (Optional):</label>
            <input type="text" name="pincode" pattern="[0-9]{6}" title="Enter a valid 6-digit Pincode">

            <label>Location (Optional):</label>
            <input type="text" name="location">

            <label>Upload Profile Picture (Optional):</label>
            <input type="file" name="profile_picture" accept="image/*">

            <label>Password:</label>
            <input type="password" name="password" required>

            <button type="submit" name="register">Register</button>
        </form>
        <?php if (isset($error_message)): ?>
            <p class="error-message"><?= htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
