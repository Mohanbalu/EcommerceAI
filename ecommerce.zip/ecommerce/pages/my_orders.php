<?php
session_start();
include '../includes/db.php';

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT o.id AS order_id, o.total_cost, o.address, o.phone, o.order_date, 
           o.payment_method, o.payment_details,
           GROUP_CONCAT(p.name SEPARATOR '|||') AS product_names,
           GROUP_CONCAT(p.id SEPARATOR '|||') AS product_ids,
           GROUP_CONCAT(p.price SEPARATOR '|||') AS product_prices,
           GROUP_CONCAT(od.quantity SEPARATOR '|||') AS product_quantities
    FROM orders o
    JOIN order_details od ON o.id = od.order_id
    JOIN products p ON od.product_id = p.id
    WHERE o.user_id = ?
    GROUP BY o.id
    ORDER BY o.order_date DESC
");

$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header("Location: ../index.php");
    exit();
}

$basket_count = $_SESSION['basket_count'] ?? 0;
$wallet_balance = $_SESSION['wallet_balance'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4F46E5;
            --primary-hover: #4338CA;
            --success-color: #059669;
            --danger-color: #DC2626;
            --warning-color: #D97706;
            --border-color: #E5E7EB;
            --text-primary: #111827;
            --text-secondary: #6B7280;
            --bg-primary: #F9FAFB;
            --bg-white: #FFFFFF;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.5;
            color: var(--text-primary);
            background-color: var(--bg-primary);
        }

        header {
            background-color: var(--bg-white);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        nav {
            display: flex;
            gap: 1rem;
        }

        .nav-link {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: var(--bg-primary);
            color: var(--primary-color);
        }

        .dropdown {
            position: relative;
        }

        .dropdown-toggle {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .dropdown-toggle:after {
            content: '';
            border-left: 5px solid transparent;
            border-right: 5px solid transparent;
            border-top: 5px solid currentColor;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            background-color: var(--bg-white);
            min-width: 200px;
            border-radius: 0.375rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border-color);
            z-index: 1000;
        }

        .dropdown-content a {
            color: var(--text-primary);
            padding: 0.75rem 1rem;
            text-decoration: none;
            display: block;
            transition: background-color 0.2s ease;
        }

        .dropdown-content a:hover {
            background-color: var(--bg-primary);
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .orders-grid {
            display: grid;
            gap: 1.5rem;
        }

        .order-card {
            background-color: var(--bg-white);
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .order-header {
            padding: 1rem;
            background-color: var(--bg-primary);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .order-id {
            font-weight: 600;
            color: var(--text-primary);
        }

        .order-date {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }

        .order-content {
            padding: 1rem;
        }

        .order-products {
            margin-bottom: 1rem;
        }

        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .product-item:last-child {
            border-bottom: none;
        }

        .product-name {
            flex: 1;
        }

        .product-quantity {
            color: var(--text-secondary);
            margin: 0 1rem;
        }

        .product-price {
            font-weight: 500;
        }

        .order-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .detail-group {
            display: flex;
            flex-direction: column;
        }

        .detail-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
        }

        .detail-value {
            font-weight: 500;
        }

        .order-footer {
            padding: 1rem;
            background-color: var(--bg-primary);
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .total-cost {
            font-weight: 600;
            font-size: 1.125rem;
        }

        .buy-again {
            display: inline-flex;
            align-items: center;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 0.375rem;
            font-weight: 500;
            transition: background-color 0.2s ease;
        }

        .buy-again:hover {
            background-color: var(--primary-hover);
        }

        .order-empty {
            text-align: center;
            padding: 3rem 1rem;
            background-color: var(--bg-white);
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .order-empty p {
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .start-shopping {
            display: inline-flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 0.375rem;
            font-weight: 500;
            transition: background-color 0.2s ease;
        }

        .start-shopping:hover {
            background-color: var(--primary-hover);
        }

        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 1rem;
            }

            nav {
                flex-wrap: wrap;
                justify-content: center;
            }

            .order-details {
                grid-template-columns: 1fr;
            }

            .order-footer {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="page-title">My Orders</h1>
            <nav>
                <a href="../index.php" class="nav-link">Home</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="dropdown">
                        <span class="dropdown-toggle">My Account</span>
                        <div class="dropdown-content">
                            <a href="editprofile.php">Edit Profile</a>
                            <a href="my_orders.php">My Orders</a>
                            <a href="account_settings.php">Account Settings</a>
                            <a href="cart.php">My Basket (<?= htmlspecialchars($basket_count) ?> items)</a>
                            <a href="smart_basket.php">My Smart Basket</a>
                            <a href="wallet.php">My Wallet (₹<?= htmlspecialchars($wallet_balance) ?>)</a>
                            <a href="contact_us.php">Contact Us</a>
                            <form method="POST" style="margin: 0;">
                                <button type="submit" name="logout" style="width: 100%; text-align: left; padding: 0.75rem 1rem; border: none; background: none; color: var(--danger-color); cursor: pointer;">Logout</button>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="nav-link">Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php if (count($orders) > 0): ?>
            <div class="orders-grid">
                <?php foreach ($orders as $order): 
                    $product_names = explode('|||', $order['product_names']);
                    $product_ids = explode('|||', $order['product_ids']);
                    $product_prices = explode('|||', $order['product_prices']);
                    $product_quantities = explode('|||', $order['product_quantities']);
                ?>
                    <div class="order-card">
                        <div class="order-header">
                            <span class="order-id">Order #<?= htmlspecialchars($order['order_id']) ?></span>
                            <span class="order-date"><?= htmlspecialchars(date('d M Y, h:i A', strtotime($order['order_date']))) ?></span>
                        </div>
                        
                        <div class="order-content">
                            <div class="order-products">
                                <?php for($i = 0; $i < count($product_names); $i++): ?>
                                    <div class="product-item">
                                        <span class="product-name"><?= htmlspecialchars($product_names[$i]) ?></span>
                                        <span class="product-quantity">×<?= htmlspecialchars($product_quantities[$i]) ?></span>
                                        <span class="product-price">₹<?= htmlspecialchars($product_prices[$i]) ?></span>
                                    </div>
                                <?php endfor; ?>
                            </div>

                            <div class="order-details">
                                <div class="detail-group">
                                    <span class="detail-label">Shipping Address</span>
                                    <span class="detail-value"><?= htmlspecialchars($order['address']) ?></span>
                                </div>
                                <div class="detail-group">
                                    <span class="detail-label">Phone Number</span>
                                    <span class="detail-value"><?= htmlspecialchars($order['phone']) ?></span>
                                </div>
                                <div class="detail-group">
                                    <span class="detail-label">Payment Method</span>
                                    <span class="detail-value"><?= htmlspecialchars($order['payment_method']) ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="order-footer">
                            <span class="total-cost">Total: ₹<?= htmlspecialchars($order['total_cost']) ?></span>
                            <div>
                                <?php foreach($product_ids as $product_id): ?>
                                    <a href="../product_detail.php?id=<?= urlencode($product_id) ?>" class="buy-again">Buy Again</a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="order-empty">
                <p>You haven't placed any orders yet.</p>
                <a href="../index.php" class="start-shopping">Start Shopping</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>