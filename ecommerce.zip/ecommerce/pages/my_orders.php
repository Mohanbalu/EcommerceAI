<?php
session_start();
include '../includes/db.php';

// Redirect to login if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch orders for the logged-in user
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT id, total_cost, address, phone, order_date, payment_method, payment_details
    FROM orders 
    WHERE user_id = ? 
    ORDER BY order_date DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header("Location: ../index.php");
    exit();
}

// Optional placeholders for the navigation menu
$basket_count = $_SESSION['basket_count'] ?? 0;
$wallet_balance = $_SESSION['wallet_balance'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        h1 {
            margin: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #333;
            color: #fff;
        }
        .order-empty {
            text-align: center;
            font-size: 18px;
            color: #555;
        }
        nav {
            display: flex;
            justify-content: center;
            padding: 10px;
        }
        .nav-link, .dropdown-toggle {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
            padding: 10px 15px;
            background-color: #444;
            border-radius: 5px;
        }
        .nav-link:hover, .dropdown-toggle:hover {
            background-color: #555;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #333;
            min-width: 200px;
            border-radius: 5px;
            z-index: 1;
        }
        .dropdown-content a {
            color: #fff;
            padding: 10px;
            display: block;
            text-decoration: none;
        }
        .dropdown-content a:hover {
            background-color: #555;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
<header>
    <h1>My Orders</h1>
    <nav>
        <a href="../index.php" class="nav-link">Home</a>
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="dropdown">
            <a class="dropdown-toggle">My Account</a>
            <div class="dropdown-content">
                <a href="editprofile.php">Edit Profile</a>
                <a href="my_orders.php">My Orders</a>
                <a href="pages/my_account.php">Account Settings</a>
                <a href="pages/cart.php">My Basket (<?= htmlspecialchars($basket_count) ?> items)</a>
                <a href="pages/smart_basket.php">My Smart Basket</a>
                <a href="pages/wallet.php">My Wallet (₹<?= htmlspecialchars($wallet_balance) ?>)</a>
                <a href="pages/contact_us.php">Contact Us</a>
                <form method="POST" style="display:inline;">
                    <button type="submit" name="logout" style="background: none; color: white; border: none; cursor: pointer;">Logout</button>
                </form>
            </div>
        </div>
        <?php else: ?>
            <a href="../pages/login.php" class="nav-link">Login</a>
        <?php endif; ?>
    </nav>
</header>
<div class="container">
    <h2>Order History</h2>
    <?php if (count($orders) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Total Cost (₹)</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Order Date</th>
                    <th>Payment Method</th>
                    <th>Payment Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order['id']) ?></td>
                        <td><?= htmlspecialchars($order['total_cost']) ?></td>
                        <td><?= htmlspecialchars($order['address']) ?></td>
                        <td><?= htmlspecialchars($order['phone']) ?></td>
                        <td><?= htmlspecialchars(date('d-M-Y h:i A', strtotime($order['order_date']))) ?></td>
                        <td><?= htmlspecialchars($order['payment_method']) ?></td>
                        <td><?= htmlspecialchars($order['payment_details']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="order-empty">You have not placed any orders yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
