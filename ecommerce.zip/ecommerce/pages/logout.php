<?php
session_start();

// Check if the logout request is made
if (isset($_POST['logout'])) {
    // Destroy all session data to log out the user
    session_unset();
    session_destroy();
    
    // Redirect to index.php (home page)
    header("Location: ../index.php");
    exit();
}
?>
